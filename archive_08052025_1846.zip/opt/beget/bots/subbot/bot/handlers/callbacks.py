import logging
import asyncio
from aiogram import Router, Bot, F, types
from aiogram.exceptions import TelegramAPIError
from aiogram.fsm.context import FSMContext
from aiogram.utils.markdown import hbold

from bot.db.database import DatabaseManager
from bot.services.captcha import CaptchaService, format_captcha_log
# from bot.services.subscription import SubscriptionService # Больше не нужен здесь?
from bot.services.channel_mgmt import ChannelManagementService
from bot.states import ManageChannels
from bot.utils.helpers import get_user_mention_html
# Импортируем коллбэки из нового файла
from bot.data.callback_data import (
    ConfirmSetupCallback, ChannelManageCallback, ChannelRemoveCallback,
    CaptchaCallback #, SubscriptionCheckCallback # Удаляем импорт
)
from bot.services.subscription import SubscriptionService
# from bot.utils.constants import DEFAULT_PARSE_MODE

from bot.middlewares.service_middleware import SubscriptionServiceMiddleware
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware
# Добавим импорт для получения экземпляров бота и БД
from bot.bot_instance import bot, db_manager

logger = logging.getLogger(__name__)
callback_router = Router(name="callback_router")

# Добавлям middleware с передачей экземпляров объектов
callback_router.message.middleware.register(DbSessionMiddleware(db_manager))
callback_router.callback_query.middleware.register(DbSessionMiddleware(db_manager))

callback_router.message.middleware.register(BotMiddleware(bot))
callback_router.callback_query.middleware.register(BotMiddleware(bot))

# Добавим специальный middleware для subscription_service
callback_router.callback_query.middleware.register(SubscriptionServiceMiddleware())

async def _delete_message_after_delay(bot: Bot, chat_id: int, message_id: int, delay: int, user_id=None, user_name=None, chat_title=None):
    """Удаляет сообщение с задержкой."""
    # Логируем запланированное удаление
    if user_id:
        logger.debug(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                               f"Запланировано удаление сообщения с подтверждением капчи через {delay} секунд", message_id))
    
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id, message_id)
        # Логируем успешное удаление
        if user_id:
            logger.debug(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                  f"Сообщение с подтверждением капчи удалено", message_id))
    except TelegramAPIError as e:
        # Логируем ошибку удаления
        if user_id:
            logger.warning(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                    f"Не удалось удалить сообщение с подтверждением капчи: {e}", message_id))
        else:
            logger.warning(f"Не удалось удалить сообщение {message_id} из чата {chat_id} после коллбека: {e}")


@callback_router.callback_query(F.data.startswith("captcha_pass_"))
async def handle_captcha_callback(callback: types.CallbackQuery, bot: Bot, db_manager: DatabaseManager):
    """Обрабатывает нажатие на кнопку капчи."""
    user = callback.from_user
    chat_id = callback.message.chat.id
    message_id = callback.message.message_id
    
    # Получаем информацию о чате и пользователе для логов
    chat_title = callback.message.chat.title or f"Чат {chat_id}"
    user_name = user.full_name

    try:
        target_user_id = int(callback.data.split("_")[-1])
    except (IndexError, ValueError):
        logger.error(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                              f"Некорректный формат callback_data: {callback.data}", message_id))
        await callback.answer("Произошла ошибка. Попробуйте снова.", show_alert=True)
        return

    # Проверяем, что кнопку нажал нужный пользователь
    if user.id != target_user_id:
        logger.warning(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                               f"Попытка нажатия на чужую капчу (для пользователя {target_user_id})", message_id))
        await callback.answer("Эта кнопка не для вас.", show_alert=True)
        return

    # Обновляем статус в БД
    await db_manager.update_user_captcha_status(user.id, chat_id, passed=True)
    logger.info(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                          f"Успешно пройдена капча! Обновлен статус в БД", message_id))

    # Редактируем исходное сообщение капчи
    user_mention = get_user_mention_html(user) # Получаем упоминание
    try:
        await bot.edit_message_text(
            text=f"✅ {user_mention}, проверка пройдена! Добро пожаловать.",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=None, # Убираем кнопку
            parse_mode="HTML"
        )
        logger.debug(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                              f"Обновлено сообщение с капчей после успешного прохождения", message_id))
        
        # Запускаем удаление этого сообщения через 5 секунд (по запросу пользователя)
        asyncio.create_task(_delete_message_after_delay(bot, chat_id, message_id, 5, user.id, user_name, chat_title))
        
        # Отвечаем на коллбек (невидимо для пользователя)
        await callback.answer()
    except TelegramAPIError as e:
        logger.error(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                              f"Не удалось отредактировать сообщение с капчей: {e}", message_id))
        # Если редактирование не удалось, просто ответим на коллбек
        await callback.answer("✅ Проверка пройдена!", show_alert=True) # Покажем алерт, раз сообщение не изменилось 

# --- Обработчики FSM управления каналами (оставляем) --- #

# ... (здесь обработчики ConfirmSetupCallback, ChannelManageCallback, ChannelRemoveCallback) ... #
# Убедитесь, что они импортированы и зарегистрированы, если они есть в этом файле
# Например:
# @callback_router.callback_query(ChannelManageCallback.filter(F.action == 'add'))
# async def handle_add_channel_button(...):
#     ...
# @callback_router.callback_query(ChannelRemoveCallback.filter())
# async def handle_remove_channel_select(...):
#     ...
# @callback_router.callback_query(ChannelManageCallback.filter(F.action == 'finish'))
# async def handle_finish_manage(...):
#     ...
# @callback_router.callback_query(ChannelManageCallback.filter(F.action == 'cancel'))
# async def handle_cancel_manage(...):
#     ...

# УДАЛЯЕМ ИЛИ КОММЕНТИРУЕМ ОБРАБОТЧИК КНОПКИ ПРОВЕРКИ ПОДПИСКИ
# @callback_router.callback_query(SubscriptionCheckCallback.filter())
# async def handle_subscription_check(query: types.CallbackQuery, callback_data: SubscriptionCheckCallback, bot: Bot, db_manager: DatabaseManager, subscription_service: SubscriptionService):
#     ...

# @callback_router.callback_query(F.data.startswith("check_sub_"))
# async def handle_subscription_check_callback(callback: types.CallbackQuery, bot: Bot, db_manager: DatabaseManager):
#     ... 

@callback_router.callback_query(F.data.startswith("subcheck:"))
async def handle_subcheck_callback(callback: types.CallbackQuery, bot: Bot, db_manager: DatabaseManager, subscription_service: SubscriptionService):
    """Обрабатывает нажатие на кнопку проверки подписки."""
    user_id = callback.from_user.id
    chat_id = callback.message.chat.id
    
    # Теперь не будем вызывать API, а просто добавим пользователя в кэш
    try:
        # Получаем все каналы, связанные с чатом
        linked_channels = await db_manager.get_linked_channels_for_chat(chat_id)
        if linked_channels:
            # Импортируем функцию обновления кэша
            from bot.services.subscription import update_subscription_cache
            
            # Добавляем пользователя в кэш подписок для каждого канала
            for channel_id in linked_channels:
                update_subscription_cache(user_id, channel_id, True)
                logger.info(f"[SUBCHECK_CALLBACK] ✅ Добавлен в кэш подписки пользователь {user_id} для канала {channel_id}")
            
            # Редактируем сообщение
            user_mention = f"<a href='tg://user?id={user_id}'>{callback.from_user.first_name}</a>"
            
            # Редактируем исходное сообщение
            await callback.message.edit_text(
                f"✅ {user_mention}, вы успешно подписались на все каналы и теперь можете отправлять сообщения!",
                parse_mode="HTML",
                reply_markup=None  # Убираем кнопки
            )
            logger.info(f"[SUBCHECK_CALLBACK] Сообщение отредактировано после успешной проверки для пользователя {user_id}")
            
            # Отправляем уведомление пользователю
            await callback.answer("✅ Проверка успешно пройдена! Вы можете отправлять сообщения.", show_alert=True)
            
            # Запускаем задачу на удаление сообщения через 5 секунд
            asyncio.create_task(
                delete_message_after_delay(bot, chat_id, callback.message.message_id, 5)
            )
    except Exception as e:
        logger.error(f"[SUBCHECK_CALLBACK] Ошибка при обработке кнопки проверки: {e}")
        await callback.answer("⚠️ Произошла ошибка при проверке подписки. Попробуйте позже.", show_alert=True)

# Вспомогательная функция для удаления сообщений
async def delete_message_after_delay(bot: Bot, chat_id: int, message_id: int, delay: int):
    """Удаляет сообщение через указанное количество секунд."""
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception as e:
        logger.error(f"Не удалось удалить сообщение {message_id} в чате {chat_id}: {e}") 