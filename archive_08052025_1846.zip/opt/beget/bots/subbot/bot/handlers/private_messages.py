import logging
from typing import Optional, List, Dict, Any, Tuple
import asyncio

from aiogram import Router, F, types, Bot
from aiogram.filters import CommandStart, CommandObject, Command
from aiogram.enums import ChatType
from aiogram.exceptions import TelegramAPIError
from aiogram.utils.markdown import hlink, hbold, hitalic, hcode, hpre

from bot.db.database import DatabaseManager
from bot.config import BOT_USERNAME
from aiogram.utils.keyboard import InlineKeyboardBuilder
from bot.data.callback_data import ManageSpecificChatCallback
from bot.utils.helpers import get_user_mention_html
from bot.bot_instance import bot, db_manager
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware

logger = logging.getLogger(__name__)
pm_router = Router()

# Регистрируем middleware
pm_router.message.middleware.register(DbSessionMiddleware(db_manager))
pm_router.callback_query.middleware.register(DbSessionMiddleware(db_manager))

pm_router.message.middleware.register(BotMiddleware(bot))
pm_router.callback_query.middleware.register(BotMiddleware(bot))

# Фильтр, чтобы роутер реагировал только на сообщения в личке
pm_router.message.filter(F.chat.type == ChatType.PRIVATE) 
pm_router.callback_query.filter(F.message.chat.type == ChatType.PRIVATE) # Добавляем фильтр для колбэков

# Хелпер для извлечения реферер ID из payload
def extract_referrer_id(payload: Optional[str]) -> Optional[int]:
    if payload and payload.isdigit():
        try:
            ref_id = int(payload)
            # Доп. проверка: ID не должен быть слишком большим или отрицательным
            if 0 < ref_id < 2**31: # Примерный диапазон для user_id
                return ref_id
        except (ValueError, TypeError):
            pass
    return None

# --- Вспомогательные функции ---

async def _get_channel_title(bot: Bot, channel_id: int) -> str:
    """Безопасно получает название канала по ID с форматированием."""
    try:
        chat = await bot.get_chat(channel_id)
        title = chat.title or f"ID: {channel_id}" # Используем ИЛИ для краткости
        link = None
        if chat.username:
            link = f"https://t.me/{chat.username}"
        # Проверяем наличие invite_link безопаснее
        elif hasattr(chat, 'invite_link') and chat.invite_link:
             link = chat.invite_link # Ссылка-приглашение для приватных каналов

        # Возвращаем ссылку если есть, иначе жирный текст
        return hlink(title, link) if link else hbold(title)
    except TelegramAPIError as e:
        logger.warning(f"Не удалось получить информацию о канале {channel_id}: {e}")
        # Оставляем курсив для ошибок
        return hitalic(f"Канал ID {channel_id} (ошибка доступа)")
    except Exception as e:
        logger.error(f"Неожиданная ошибка при получении информации о канале {channel_id}: {e}", exc_info=True)
        return hitalic(f"Канал ID {channel_id} (ошибка)")

async def _format_configured_chats(bot: Bot, db_manager: DatabaseManager, user_id: int) -> Tuple[str, Optional[types.InlineKeyboardMarkup]]:
    """Формирует текст и клавиатуру со списком чатов и каналов.
    
    Returns:
        Кортеж (text, keyboard)
    """
    configured_chats = await db_manager.get_chats_configured_by_user(user_id)
    builder = InlineKeyboardBuilder() # Создаем билдер клавиатуры
    
    if not configured_chats:
        text = (
            f"Вы пока не настроили проверку подписок ни в одном чате.\n\n"
            f"➡️ Чтобы начать, добавьте меня (@{BOT_USERNAME}) в нужную группу и "
            f"используйте команду /getcode, чтобы получить код настройки."
        )
        return text, None # Возвращаем текст без клавиатуры

    text_parts = ["\n✨ <b>Ваши настроенные чаты и каналы:</b>\n"]
    for i, chat_info in enumerate(configured_chats):
        chat_id = chat_info.get('chat_id')
        chat_title = chat_info.get('chat_title') or f"Чат {chat_id}"
        
        # Создаем гиперссылку на чат
        chat_link = get_chat_link_html(chat_id, chat_title)
        text_parts.append(f"\n{i+1}. 💬 {chat_link}")

        channel_ids = chat_info.get('channels', [])
        if channel_ids:
            channel_tasks = [_get_channel_title(bot, ch_id) for ch_id in channel_ids]
            channel_titles = await asyncio.gather(*channel_tasks)
            channels_str = "\n".join([f"   • {title}" for title in channel_titles])
            text_parts.append(f"   └─ Каналы для проверки:\n{channels_str}")
        else:
            text_parts.append("   └─ Каналы для проверки: (нет)")
            
        # Добавляем кнопку управления для этого чата
        if chat_id: # Убедимся, что ID чата есть
             builder.button(
                 text=f"⚙️ Управлять '{chat_title[:20]}{'...' if len(chat_title) > 20 else ''}'",
                 callback_data=ManageSpecificChatCallback(chat_id=chat_id).pack()
             )

    text_parts.append(
        f"\n\n💡 Используйте команду /getcode для настройки нового чата."
    )
    
    builder.adjust(1) # Кнопки управления по одной в ряд
    keyboard = builder.as_markup() if configured_chats else None # Клавиатура только если есть чаты
    
    return "\n".join(text_parts), keyboard

# Функция для создания HTML-ссылки на чат
def get_chat_link_html(chat_id: int, chat_title: str) -> str:
    """Создает HTML-ссылку на чат."""
    # Убираем -100 из ID чата для корректной ссылки
    link_id = str(chat_id).replace('-100', '')
    return hlink(chat_title, f"https://t.me/c/{link_id}")

# --- Обработчики команд ---

@pm_router.message(Command("getcode"))
async def cmd_get_setup_code(message: types.Message):
    """Отправляет пользователю код для активации настройки группы."""
    user = message.from_user
    if not user:
        return # Маловероятно в ЛС, но проверка не помешает

    # Генерируем код. Можно использовать что-то более уникальное,
    # но для простоты user_id достаточен, если не ожидается конфликтов.
    setup_code = f"setup_{user.id}"
    logger.info(f"Пользователь {user.id} ({user.username}) запросил код настройки: {setup_code}")

    text = (
        f"🔑 Ваш уникальный код для настройки группы:\n\n"
        f"   {hcode(setup_code)}\n\n"
        f"Скопируйте этот код (нажмите на него) и отправьте его "
        f"<b>одним сообщением</b> в ту группу, где вы хотите настроить "
        f"проверку подписки на каналы."
    )
    # Используем parse_mode="HTML" из aiogram.enums.ParseMode для консистентности, если импортируем
    await message.answer(text, parse_mode="HTML")

@pm_router.message(CommandStart(deep_link=True, deep_link_encoded=False))
@pm_router.message(CommandStart())
async def cmd_start_in_pm(message: types.Message, command: CommandObject, db_manager: DatabaseManager, bot: Bot):
    """Обработчик команды /start в личных сообщениях."""
    user = message.from_user
    if not user:
        logger.warning("Получено сообщение /start без информации о пользователе.")
        return

    start_payload = command.args
    referrer_id = extract_referrer_id(start_payload)
    # Проверяем, что реферер не сам пользователь
    actual_referrer_id = referrer_id if referrer_id and user.id != referrer_id else None

    logger.info(f"Пользователь {user.id} ({user.username or 'no_username'}) запустил /start в ЛС. Payload: {start_payload}, Referrer ID: {actual_referrer_id}")

    # 1. Проверяем, есть ли пользователь в БД
    existing_user_data = await db_manager.get_user(user.id)
    is_new_user = existing_user_data is None

    # 2. Добавляем или обновляем пользователя
    # Метод add_user_if_not_exists сам обрабатывает оба случая (новый/существующий)
    await db_manager.add_user_if_not_exists(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        language_code=user.language_code,
        is_premium=bool(user.is_premium), # Приводим к bool на всякий случай
        referrer_id=actual_referrer_id if is_new_user else None # Передаем реферера только если пользователь новый
    )

    # Если пользователь не новый, но реферера у него не было, а сейчас пришел с ним
    if not is_new_user and actual_referrer_id and existing_user_data and existing_user_data.get('referrer_id') is None:
         try:
             await db_manager.record_referral(referred_id=user.id, referrer_id=actual_referrer_id)
             logger.info(f"Записан реферер {actual_referrer_id} для существующего пользователя {user.id}")
         except Exception as e: # Ловим возможные ошибки БД
             logger.error(f"Ошибка при записи реферера {actual_referrer_id} для {user.id}: {e}")

    # 3. Формируем ответ
    user_mention = hlink(user.first_name or "Пользователь", f"tg://user?id={user.id}")

    if is_new_user:
        text_parts = [
            f"👋 Привет, {user_mention}!\n",
            f"Я — бот для проверки подписки на каналы в ваших группах.",
            f"С моей помощью вы можете гарантировать, что новые участники подписаны на важные каналы перед тем, как писать в чат.\n",
            f"📌 <b>Как начать:</b>",
            f"1️⃣ Добавьте меня (@{BOT_USERNAME}) в вашу группу.",
            f"2️⃣ Выдайте права администратора (желательно, для удаления сервисных сообщений).",
            f"3️⃣ Используйте команду /getcode прямо здесь, в личных сообщениях со мной, чтобы получить код настройки.",
            f"4️⃣ Отправьте полученный код в группу.\n",
            f"ℹ️ Доступные команды можно посмотреть здесь: /help"
        ]
        # Добавляем информацию о реферере, если он есть
        if actual_referrer_id:
             referrer_info = await db_manager.get_user(actual_referrer_id)
             ref_mention = f"пользователя {hitalic(str(actual_referrer_id))}" # Запасной вариант
             if referrer_info:
                 # Используем имя или username, если есть
                 ref_name = referrer_info.get('first_name') or referrer_info.get('username')
                 if ref_name:
                      # Создаем ссылку на профиль реферера
                     ref_mention = f"пользователя {hlink(ref_name, f'tg://user?id={actual_referrer_id}')}"
             text_parts.append(f"\n🤝 P.S. Вы присоединились по приглашению {ref_mention}!")
        text = "\n".join(text_parts)

    else:
        # Ответ для вернувшегося пользователя
        welcome_back = f"👋 С возвращением, {user_mention}!"
        # Получаем список настроенных чатов
        chats_list_text, keyboard = await _format_configured_chats(bot, db_manager, user.id)
        # Объединяем приветствие и список
        text = f"{welcome_back}\n{chats_list_text}"
        # Удаляем напоминание о командах
        # text += f"\n\nДоступные команды: /getcode, /mychats, /help"

    # Отправляем ответное сообщение
    # Убираем клавиатуру, так как она теперь пустая
    await message.answer(text, parse_mode="HTML", disable_web_page_preview=True)

@pm_router.message(Command("mychats"))
async def cmd_mychats(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    """Показывает список чатов и каналов, настроенных пользователем."""
    user = message.from_user
    if not user:
        return

    logger.info(f"Пользователь {user.id} ({user.username or 'no_username'}) запросил /mychats")
    # Получаем текст и клавиатуру
    text, keyboard = await _format_configured_chats(bot, db_manager, user.id)
    await message.answer(text, reply_markup=keyboard, parse_mode="HTML", disable_web_page_preview=True)

@pm_router.message(Command("help"))
async def cmd_help(message: types.Message):
    """Показывает справочную информацию о командах бота."""
    user = message.from_user
    if not user: return

    logger.info(f"Пользователь {user.id} ({user.username or 'no_username'}) запросил /help")

    # Используем hbold и hcode для форматирования
    text = (
        f"ℹ️ <b>Справка по командам бота:</b>\n\n"
        f"{hbold('/start')} - Начать работу с ботом и получить инструкции.\n"
        f"{hbold('/getcode')} - Получить уникальный код для настройки проверки подписок в новой группе. Код нужно отправить в саму группу.\n"
        f"{hbold('/mychats')} - Показать список групп, где вы уже настроили проверку подписок, и каналы, которые там проверяются.\n"
        f"{hbold('/help')} - Показать это справочное сообщение.\n\n"
        f"⚠️ {hitalic('Важно:')} Настройка каналов для проверки происходит непосредственно в той группе, куда вы добавили бота, после отправки туда кода, полученного через /getcode."
    )

    await message.answer(text, parse_mode="HTML", disable_web_page_preview=True)

# Убедитесь, что pm_router импортирован и используется в основном файле бота (__main__.py)
# dp.include_router(pm_router)
