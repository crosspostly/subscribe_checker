"""
Обработчики для администрирования бота в группах.

Содержит:
- Обработчик добавления/изменения прав бота в чате.
- Обработчики FSM для выбора канала.
"""
import logging
from aiogram import Router, Bot, F, types
from aiogram.filters import Command, ChatMemberUpdatedFilter, ADMINISTRATOR, Filter, IS_ADMIN, IS_MEMBER
from aiogram.enums import ChatType, ContentType, ChatMemberStatus
from aiogram.fsm.context import FSMContext
from aiogram.types import ChatMemberUpdated, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.fsm.storage.base import StorageKey
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError
from typing import Union, Dict, Any
from aiogram.utils.markdown import hbold, hlink

# Используем абсолютные импорты
from bot.db.database import DatabaseManager
from bot.config import BOT_USERNAME # Для формирования сообщений
from bot.keyboards.inline import get_confirm_setup_keyboard
from bot.services.channel_mgmt import ChannelManagementService
from bot.utils.helpers import get_user_mention_html
from bot.states import ManageChannels
from bot.bot_instance import bot, db_manager
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware

logger = logging.getLogger(__name__)
group_admin_router = Router() # <--- Определение роутера

# Регистрируем middleware
group_admin_router.message.middleware.register(DbSessionMiddleware(db_manager))
group_admin_router.chat_member.middleware.register(DbSessionMiddleware(db_manager))
group_admin_router.my_chat_member.middleware.register(DbSessionMiddleware(db_manager))
group_admin_router.callback_query.middleware.register(DbSessionMiddleware(db_manager))

group_admin_router.message.middleware.register(BotMiddleware(bot))
group_admin_router.chat_member.middleware.register(BotMiddleware(bot))
group_admin_router.my_chat_member.middleware.register(BotMiddleware(bot))
group_admin_router.callback_query.middleware.register(BotMiddleware(bot))

# Фильтр на тип чата (группа или супергруппа)
group_admin_router.message.filter(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}))
group_admin_router.chat_member.filter(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}))

# --- Фильтр для кодов setup_{user_id} ---
class SetupCodeFilter(Filter):
    async def __call__(self, message: types.Message) -> Union[bool, Dict[str, Any]]:
        if not message.text:
            return False
        parts = message.text.strip().split('_')
        if len(parts) == 2 and parts[0] == 'setup' and parts[1].isdigit():
            user_id_to_setup = int(parts[1])
            # Возвращаем ID пользователя из кода для использования в хендлере
            return {"user_id_to_setup": user_id_to_setup}
        return False

# --- Обработчики изменения статуса администраторов --- #

# 1. Пользователь становится администратором (раньше не был)
@group_admin_router.chat_member(
    ChatMemberUpdatedFilter(member_status_changed=IS_MEMBER >> IS_ADMIN)
)
# 2. У существующего администратора меняются права
@group_admin_router.chat_member(
    ChatMemberUpdatedFilter(member_status_changed=IS_ADMIN >> IS_ADMIN)
)
async def on_admin_status_change(event: ChatMemberUpdated, bot: Bot, db_manager: DatabaseManager):
    """Реагирует на назначение админа или изменение его прав."""
    chat_id = event.chat.id
    chat_title = event.chat.title or f"Чат ID {chat_id}"
    new_admin_user = event.new_chat_member.user
    actor_user = event.from_user # Кто выполнил действие

    logger.info(f"[ADMIN_EVENT] В чате {chat_id} ('{chat_title}') изменился статус/права admin {new_admin_user.id} ({new_admin_user.full_name}). Инициатор: {actor_user.id}")

    # Если бота назначили админом
    bot_info = await bot.get_me()
    if new_admin_user.id == bot_info.id:
        logger.info(f"[ADMIN_EVENT] Меня ({bot_info.username}) назначили админом в чате {chat_id}. Добавляю чат в БД.")
        # Добавляем чат в БД, если его еще нет
        await db_manager.add_chat_if_not_exists(
            chat_id=chat_id,
            chat_title=chat_title,
            added_by_user_id=actor_user.id
        )
        # Отправляем приветственное сообщение с инструкцией
        try:
            await bot.send_message(
                chat_id,
                f"👋 Привет! Я готов к работе в чате {hbold(chat_title)}.\n"
                f"Администратор ({hlink(actor_user.first_name, f'tg://user?id={actor_user.id}')}) может теперь настроить меня.\n\n"
                f"➡️ Чтобы начать, получите код настройки в личных сообщениях со мной (@{bot_info.username}), используя команду /getcode, "
                f"а затем отправьте этот код сюда.",
                parse_mode="HTML",
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.warning(f"[ADMIN_EVENT] Не удалось отправить приветствие в чат {chat_id}: {e}")
    else:
        # Если назначили другого пользователя админом
        # Можно отправить ему (или в чат) краткую инструкцию
        logger.debug(f"[ADMIN_EVENT] Статус пользователя {new_admin_user.id} изменен на админа в чате {chat_id}.")
        # Просто логируем, дальнейших действий не требуется по ТЗ
        pass

# --- Обработка разжалования (опционально) --- #
# @group_admin_router.chat_member(
#     ChatMemberUpdatedFilter(member_status_changed=IS_ADMIN >> IS_MEMBER)
# )
# async def on_admin_demoted(...):
#     ...

# --- Хендлеры --- #

# Добавление бота в админы или изменение его прав
@group_admin_router.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=ADMINISTRATOR))
async def handle_admin_promotion_wrapper(event: types.ChatMemberUpdated, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает ситуацию, когда боту выдали права администратора."""
    # Логика может остаться прежней или быть адаптирована под новый флоу
    # Пока оставим как есть, но возможно, ее стоит объединить с flow через код
    # !!! ВНИМАНИЕ: Код ниже использует старый state.key(), его тоже нужно исправить !!!
    user_id_who_promoted = event.from_user.id
    bot_id = bot.id
    user_fsm_key = StorageKey(bot_id=bot_id, chat_id=user_id_who_promoted, user_id=user_id_who_promoted)
    user_state = FSMContext(storage=state.storage, key=user_fsm_key)
    
    # channel_mgmt_service = ChannelManagementService(bot, db_manager)
    # await channel_mgmt_service.handle_admin_promotion(event, user_state)

# Обработка кода setup_{user_id} в группе
@group_admin_router.message(SetupCodeFilter())
async def handle_setup_code(message: types.Message, bot: Bot, db_manager: DatabaseManager, user_id_to_setup: int):
    """Обрабатывает код вида setup_{user_id}, отправленный в группу."""
    sender = message.from_user
    chat = message.chat
    chat_title = chat.title or f"ID {chat.id}"

    logger.info(f"Получен код настройки {message.text} в чате {chat.id} ('{chat_title}') от {sender.id} ({sender.username}). Целевой пользователь: {user_id_to_setup}")

    # Пытаемся удалить сообщение с кодом
    try: 
        await message.delete()
        logger.info(f"Сообщение с кодом {message.text} удалено из чата {chat.id}.")
    except TelegramAPIError as e:
        logger.warning(f"Не удалось удалить сообщение с кодом {message.text} из чата {chat.id}: {e}")

    # Проверяем, существует ли целевой пользователь
    target_user = await db_manager.get_user(user_id_to_setup)
    if not target_user:
        logger.warning(f"Целевой пользователь {user_id_to_setup} из кода не найден в БД.")
        # Можно отправить сообщение в группу, но лучше этого не делать, чтобы не спамить
        return

    # Отправляем сообщение с подтверждением в ЛС целевому пользователю
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Да, настроить этот чат", callback_data=f"confirm_setup:{chat.id}")],
        [InlineKeyboardButton(text="❌ Нет, отмена", callback_data="cancel_setup")]
    ])

    sender_mention = get_user_mention_html(sender) if sender else "Кто-то"
    text_to_pm = (
        f"{sender_mention} активировал код настройки для группы <b>{chat_title}</b>.\n\n"
        f"Хотите настроить проверку каналов для этой группы?"
    )

    try:
        await bot.send_message(user_id_to_setup, text_to_pm, reply_markup=keyboard, parse_mode="HTML")
        logger.info(f"Отправлен запрос подтверждения настройки пользователю {user_id_to_setup} для чата {chat.id}.")
    except TelegramForbiddenError:
        logger.warning(f"Не удалось отправить ЛС пользователю {user_id_to_setup} (бот заблокирован?). Чат {chat.id}.")
        # Сообщаем об ошибке в группу
        try:
             target_user_mention = get_user_mention_html(target_user) or f"пользователь {user_id_to_setup}"
             await bot.send_message(chat.id, f"Не удалось отправить запрос на настройку пользователю {target_user_mention}. Возможно, он заблокировал бота.", parse_mode="HTML")
        except Exception as group_send_err:
             logger.error(f"Не удалось отправить сообщение об ошибке блокировки в чат {chat.id}: {group_send_err}")
    except TelegramAPIError as e:
        logger.error(f"Ошибка API при отправке запроса подтверждения пользователю {user_id_to_setup} для чата {chat.id}: {e}")
        # Сообщаем об ошибке в группу
        try:
            target_user_mention = get_user_mention_html(target_user) or f"пользователь {user_id_to_setup}"
            await bot.send_message(chat.id, f"Произошла ошибка при отправке запроса пользователю {target_user_mention}. Попробуйте позже.", parse_mode="HTML")
        except Exception as group_send_err:
            logger.error(f"Не удалось отправить сообщение об ошибке API в чат {chat.id}: {group_send_err}")

# --- Управление каналами для уже настроенного чата ---

@group_admin_router.message(Command("managechannels"))
async def cmd_manage_channels(message: types.Message, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает команду /managechannels для управления списком каналов."""
    user = message.from_user
    chat = message.chat
    chat_title = chat.title or f"ID {chat.id}"

    # 0. Проверяем, есть ли чат в базе и завершена ли настройка
    chat_settings = await db_manager.get_chat_settings(chat.id)
    if not chat_settings:
        # Это не должно происходить, если бот добавлен/настроен, но на всякий случай
        logger.warning(f"Попытка /managechannels в чате {chat.id}, который не найден в БД.")
        await message.reply("😕 Не могу найти информацию об этом чате. Убедитесь, что я добавлен как администратор.")
        return
    if not chat_settings.get('setup_complete', False):
        logger.info(f"Попытка /managechannels в чате {chat.id}, который еще не настроен.")
        await message.reply(f"⚙️ Этот чат еще не настроен. Используйте команду /getcode в моих личных сообщениях (@{BOT_USERNAME}), а затем пришлите полученный код сюда для начала настройки.")
        return

    # 1. Проверяем, является ли пользователь администратором чата
    try:
        member = await bot.get_chat_member(chat_id=chat.id, user_id=user.id)
        if not isinstance(member, (types.ChatMemberOwner, types.ChatMemberAdministrator)):
            logger.warning(f"Пользователь {user.id} ({user.full_name}) попытался использовать /managechannels в чате {chat.id}, не будучи админом.")
            await message.reply("Эта команда доступна только администраторам чата.")
            return
        # Дополнительно проверяем право на управление чатом (invite_users), если нужно строже
        # if isinstance(member, types.ChatMemberAdministrator) and not member.can_invite_users:
        #     logger.warning(f"Администратор {user.id} попытался использовать /managechannels в чате {chat.id} без права 'invite_users'.")
        #     await message.reply("У вас недостаточно прав для управления настройками каналов.")
        #     return

    except TelegramAPIError as e:
        logger.error(f"Ошибка проверки статуса админа {user.id} в чате {chat.id}: {e}")
        await message.reply("Не удалось проверить ваши права администратора. Попробуйте позже.")
        return

    logger.info(f"Админ {user.id} ({user.full_name}) инициировал /managechannels в чате {chat.id} ('{chat_title}').")

    # 2. Удаляем команду из чата
    try:
        await message.delete()
    except TelegramAPIError as e:
        logger.warning(f"Не удалось удалить сообщение /managechannels из чата {chat.id}: {e}")

    # 3. Инициируем процесс управления в ЛС
    # Используем сервис для инкапсуляции логики
    # TODO: Создать ChannelManagementService или использовать существующий
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage) # Передаем storage для FSM
    await channel_mgmt_service.start_channel_management(
        target_chat_id=chat.id,
        target_chat_title=chat_title,
        admin_user_id=user.id
    )

# --- Остальные хендлеры FSM (перенесены или будут перенесены) ---

# Выбор канала через ChatShared (FSM) - ПЕРЕНЕСЕНО в fsm_private.py
# @group_admin_router.message(...)

# Неверный ввод при выборе канала (FSM) - ПЕРЕНЕСЕНО в fsm_private.py
# @group_admin_router.message(...)
# async def handle_wrong_channel_select_wrapper(...) 