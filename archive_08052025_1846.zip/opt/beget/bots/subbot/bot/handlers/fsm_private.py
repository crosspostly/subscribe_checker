"""
Обработчики состояний FSM, ожидаемых в личном чате с ботом.

Содержит:
- Обработка выбора канала через ChatShared.
- Обработка неверного ввода при ожидании выбора канала.
"""
import logging
from aiogram import Router, Bot, F, types
from aiogram.enums import ChatType, ContentType
from aiogram.fsm.context import FSMContext
from aiogram.filters.callback_data import CallbackData
from aiogram.exceptions import TelegramAPIError
from typing import List, Dict

# Используем абсолютные импорты
from bot.db.database import DatabaseManager
from bot.states import ManageChannels
from bot.services.channel_mgmt import ChannelManagementService
from bot.services.subscription import SubscriptionService
from bot.bot_instance import bot, db_manager
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware
# Убираем старые колбэки, они теперь не используются напрямую в хендлерах
# from bot.keyboards.inline import ConfirmSetupCallback, ChannelManageCallback, ChannelRemoveCallback
# Используем CallbackData только если он нужен для фильтрации
from aiogram.filters.callback_data import CallbackData 
# Импортируем новый CallbackData
from bot.data.callback_data import ConfirmSetupCallback, ManageSpecificChatCallback 

logger = logging.getLogger(__name__)
fsm_private_router = Router()

# Регистрируем middleware
fsm_private_router.message.middleware.register(DbSessionMiddleware(db_manager))
fsm_private_router.callback_query.middleware.register(DbSessionMiddleware(db_manager))

fsm_private_router.message.middleware.register(BotMiddleware(bot))
fsm_private_router.callback_query.middleware.register(BotMiddleware(bot))

# Фильтр на тип чата (личный)
fsm_private_router.message.filter(F.chat.type == ChatType.PRIVATE)
fsm_private_router.callback_query.filter(F.message.chat.type == ChatType.PRIVATE)

# --- CallbackData для кнопки подтверждения (из group_admin) ---
# Перенесем сюда, если ConfirmSetupCallback используется только здесь
class ConfirmSetupCallback(CallbackData, prefix="confirm_setup"):
    chat_id: int

# --- Обработчики FSM и коллбэков в ЛС --- #

# --- Обработчик кнопки "Управлять" из /mychats --- #

@fsm_private_router.callback_query(ManageSpecificChatCallback.filter())
async def handle_manage_specific_chat(query: types.CallbackQuery, callback_data: ManageSpecificChatCallback, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает нажатие кнопки 'Управлять' из списка /mychats."""
    user = query.from_user
    chat_id_to_manage = callback_data.chat_id

    logger.info(f"[MYCHATS_CB] Пользователь {user.id} нажал 'Управлять' для чата {chat_id_to_manage}")

    # Получаем название чата
    chat_title = f"ID {chat_id_to_manage}" # Запасной вариант
    try:
        chat_info = await bot.get_chat(chat_id_to_manage)
        chat_title = chat_info.title or chat_title
    except TelegramAPIError as e:
        logger.warning(f"[MYCHATS_CB] Не удалось получить title для чата {chat_id_to_manage} при управлении: {e}")
        # Продолжаем с ID
    
    # Инициализируем сервис управления каналами (передаем storage!)
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    try:
        # Запускаем процесс управления каналами для этого чата
        await channel_mgmt_service.start_channel_management(
            target_chat_id=chat_id_to_manage,
            target_chat_title=chat_title,
            admin_user_id=user.id
        )
        # Убираем инлайн клавиатуру у сообщения /mychats (опционально)
        # await query.message.edit_reply_markup(reply_markup=None)
        await query.answer() # Отвечаем на коллбэк

    except Exception as e:
        logger.error(f"[MYCHATS_CB] Ошибка при запуске управления каналами для chat={chat_id_to_manage} user={user.id}: {e}", exc_info=True)
        await state.clear() # На всякий случай чистим state
        try:
            await query.answer("Произошла ошибка при запуске управления каналами.", show_alert=True)
            # Можно отредактировать сообщение /mychats с текстом ошибки?
            # await query.message.edit_text("Произошла ошибка при запуске управления каналами.")
        except TelegramAPIError: pass

# Нажатие кнопки "Да, настроить этот чат"
@fsm_private_router.callback_query(ConfirmSetupCallback.filter())
async def handle_confirm_setup(query: types.CallbackQuery, callback_data: ConfirmSetupCallback, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает подтверждение настройки чата из ЛС."""
    user = query.from_user
    chat_id_to_setup = callback_data.chat_id

    logger.info(f"Пользователь {user.id} подтвердил настройку чата {chat_id_to_setup}")

    # Получаем информацию о чате, чтобы показать название
    chat_title = f"ID {chat_id_to_setup}"
    try:
        chat_info = await bot.get_chat(chat_id_to_setup)
        chat_title = chat_info.title or chat_title
    except TelegramAPIError as e:
        logger.warning(f"Не удалось получить title для чата {chat_id_to_setup} при подтверждении: {e}")
        # Продолжаем с ID

    # Инициализируем сервис и запускаем FSM
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    try:
        # Вызываем НОВЫЙ метод старта управления, который сам управляет FSM
        await channel_mgmt_service.start_channel_management(
            target_chat_id=chat_id_to_setup,
            target_chat_title=chat_title,
            admin_user_id=user.id
        )
        # Убираем инлайн клавиатуру у исходного сообщения подтверждения
        await query.message.edit_reply_markup(reply_markup=None)
        await query.answer() # Отвечаем на коллбэк

    except Exception as e:
        logger.error(f"[FSM_CHANNEL] Ошибка FSM/отправки для user={user.id} после подтверждения настройки chat={chat_id_to_setup}: {e}")
        await state.clear()
        try:
            await query.answer("Произошла ошибка при начале настройки.", show_alert=True)
            await query.message.edit_text("Произошла ошибка. Попробуйте получить код и активировать его снова.")
        except TelegramAPIError: pass

# Нажатие кнопки "Нет, отмена"
@fsm_private_router.callback_query(F.data == "cancel_setup")
async def handle_cancel_setup(query: types.CallbackQuery, state: FSMContext):
    """Обрабатывает отмену настройки (на этапе подтверждения)."""
    # Эта кнопка относится к изначальному подтверждению, не к интерфейсу управления
    logger.info(f"Пользователь {query.from_user.id} отменил настройку на этапе подтверждения.")
    await query.answer("Настройка отменена.")
    # Убедимся что состояние чистое, если оно вдруг было установлено
    await state.clear()
    try:
        await query.message.edit_text("Настройка чата отменена.") # Убираем кнопки
    except TelegramAPIError as e:
        logger.warning(f"Не удалось отредактировать сообщение отмены для user={query.from_user.id}: {e}")

# --- Обработчики FSM для добавления/выбора канала --- #

# Выбор канала через ChatShared (состояние adding_channel)
@fsm_private_router.message(
    ManageChannels.adding_channel,
    F.content_type == ContentType.CHAT_SHARED
)
async def handle_channel_select_adding(message: types.Message, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает выбор канала через forwarded CHAT_SHARED в ЛС при добавлении нового канала."""
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    await channel_mgmt_service.handle_channel_select(message, state)

# Обработка неверного ввода при добавлении канала
@fsm_private_router.message(
    ManageChannels.adding_channel,
    ~F.content_type == ContentType.CHAT_SHARED
)
async def handle_wrong_channel_select_adding(message: types.Message, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает неверный ввод при добавлении нового канала."""
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    await channel_mgmt_service.handle_wrong_channel_select(message, state)

# --- Обработчики кнопок интерфейса управления (состояние managing_list) ---

# Кнопка "➕ Добавить канал"
@fsm_private_router.callback_query(ManageChannels.managing_list, F.data == "mng:add_channel")
async def handle_add_channel_button(query: types.CallbackQuery, state: FSMContext, bot: Bot, db_manager: DatabaseManager):
    """Обработка кнопки 'Добавить канал'. Запрашивает выбор канала."""
    user_id = query.from_user.id
    logger.info(f"[MGMT_CB] user={user_id} нажал 'Добавить канал'")
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    try:
        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        if not target_chat_id:
            logger.error(f"[MGMT_CB] Нет target_chat_id в state при добавлении канала user={user_id}")
            await query.answer("Ошибка: не найден ID чата. Начните сначала.", show_alert=True)
            await state.clear()
            return
        
        await state.set_state(ManageChannels.adding_channel) # Переводим в состояние ожидания выбора
        # Вызываем метод запроса выбора канала
        await channel_mgmt_service._ask_channel_selection(user_id, target_chat_id, query.message) 
        await query.answer() # Отвечаем на коллбэк
        # Не редактируем сообщение здесь, _ask_channel_selection отправит новое с ReplyKeyboard
        
    except Exception as e:
        logger.error(f"[MGMT_CB] Ошибка при обработке 'Добавить канал' user={user_id}: {e}", exc_info=True)
        await query.answer("Произошла ошибка при попытке добавить канал.", show_alert=True)
        # Возвращаем состояние и обновляем интерфейс, если возможно
        try: 
            await state.set_state(ManageChannels.managing_list)
            await channel_mgmt_service.update_management_interface(user_id, state)
        except: 
            await state.clear()

# Кнопка "➖ Удалить 'Канал'"
# Используем F.data.startswith() для захвата ID канала
@fsm_private_router.callback_query(ManageChannels.managing_list, F.data.startswith("mng:remove_start:"))
async def handle_remove_channel_button(query: types.CallbackQuery, state: FSMContext, bot: Bot, db_manager: DatabaseManager):
    """Обработка кнопки 'Удалить канал'. Удаляет канал из state и обновляет интерфейс."""
    user_id = query.from_user.id
    try:
        channel_id_to_remove = int(query.data.split(":")[-1])
    except (IndexError, ValueError):
        logger.error(f"[MGMT_CB] Неверный формат callback_data для удаления: {query.data} user={user_id}")
        await query.answer("Ошибка: неверный ID канала для удаления.")
        return
        
    logger.info(f"[MGMT_CB] user={user_id} нажал 'Удалить канал' ID={channel_id_to_remove}")
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    try:
        state_data = await state.get_data()
        current_channels: List[Dict] = state_data.get('current_channels', [])
        target_chat_id = state_data.get('target_chat_id') # Для логирования

        removed_channel_title = f"ID {channel_id_to_remove}"
        new_channels_list = []
        found = False
        for ch_data in current_channels:
            if ch_data['id'] == channel_id_to_remove:
                removed_channel_title = ch_data.get('title', removed_channel_title)
                found = True
            else:
                new_channels_list.append(ch_data)

        if found:
            await state.update_data(current_channels=new_channels_list)
            logger.info(f"[MGMT_CB] Канал {channel_id_to_remove} ('{removed_channel_title}') временно удален user={user_id}, chat={target_chat_id}")
            await query.answer(f"Канал '{removed_channel_title}' удален из временного списка.")
            # Обновляем интерфейс
            await channel_mgmt_service.update_management_interface(user_id, state)
        else:
            logger.warning(f"[MGMT_CB] Канал {channel_id_to_remove} не найден в state для удаления user={user_id}, chat={target_chat_id}")
            await query.answer("Этот канал уже был удален.", show_alert=True)
            # На всякий случай обновим интерфейс, если state рассинхронизировался
            await channel_mgmt_service.update_management_interface(user_id, state)
            
    except Exception as e:
        logger.error(f"[MGMT_CB] Ошибка при удалении канала {channel_id_to_remove} user={user_id}: {e}", exc_info=True)
        await query.answer("Произошла ошибка при удалении канала.", show_alert=True)
        # Попытаемся обновить интерфейс
        try: await channel_mgmt_service.update_management_interface(user_id, state)
        except: pass

# Кнопка "✅ Готово"
@fsm_private_router.callback_query(ManageChannels.managing_list, F.data == "mng:finish")
async def handle_finish_button(query: types.CallbackQuery, state: FSMContext, bot: Bot, db_manager: DatabaseManager):
    """Обработка кнопки 'Готово'. Сохраняет изменения в БД."""
    user_id = query.from_user.id
    logger.info(f"[MGMT_CB] user={user_id} нажал 'Готово'")
    # ИСПРАВЛЕНИЕ: Передаем state.storage
    channel_mgmt_service = ChannelManagementService(bot, db_manager, state.storage)
    await channel_mgmt_service.handle_finish_channel_management(query, state)