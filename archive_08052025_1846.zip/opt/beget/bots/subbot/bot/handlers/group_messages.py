"""
Обработчик обычных текстовых сообщений в группах.
Вызывает сервисы для проверки капчи и подписки.
"""
import logging
from typing import Dict, Any, Optional
from aiogram import Router, Bot, F, types, Dispatcher
from aiogram.enums import ChatType, ChatMemberStatus
from aiogram.exceptions import TelegramAPIError
from aiogram.filters import ChatMemberUpdatedFilter, IS_ADMIN, IS_NOT_MEMBER, MEMBER
from aiogram.types import ChatMemberUpdated
from aiogram.utils.markdown import hlink, hbold
from aiogram.fsm.context import FSMContext
from datetime import datetime
import asyncio
import time

# Импорты
from bot.db.database import DatabaseManager
from bot.services.captcha import CaptchaService, format_captcha_log
from bot.services.subscription import SubscriptionService
from bot.config import BOT_USERNAME # Для проверки упоминаний
from bot.services.channel_mgmt import ChannelManagementService
from bot.utils.helpers import get_user_mention_html # Для упоминания пользователя
from bot.bot_instance import bot, db_manager
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware

logger = logging.getLogger(__name__)
group_msg_router = Router()

# Регистрируем middleware
group_msg_router.message.middleware.register(DbSessionMiddleware(db_manager))
group_msg_router.chat_member.middleware.register(DbSessionMiddleware(db_manager))

group_msg_router.message.middleware.register(BotMiddleware(bot))
group_msg_router.chat_member.middleware.register(BotMiddleware(bot))

# Фильтр, чтобы этот роутер реагировал только на сообщения в группах/супергруппах
group_msg_router.message.filter(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}))

# Вспомогательные функции для форматирования
def get_chat_link(chat_id, chat_title=None):
    """Создаёт ссылку на чат в формате Markdown."""
    if not chat_title:
        chat_title = f"Чат {chat_id}"
    return f"[{chat_title}](https://t.me/c/{str(chat_id).replace('-100', '')})"

def get_user_link(user_id, user_name=None):
    """Создаёт ссылку на пользователя в формате HTML."""
    if not user_name:
        user_name = f"Пользователь {user_id}"
    return f"<a href='tg://user?id={user_id}'>{user_name}</a>"

# Вспомогательная функция для вывода сообщений в лог с гиперссылками
def format_log_message(message_type, chat_id, chat_title, user_id=None, user_name=None, extra_info=None):
    """Форматирует сообщение для логирования с названиями чатов и именами пользователей."""
    chat_info = f"{chat_title} (ID: {chat_id})"
    user_info = f"{user_name} (ID: {user_id})" if user_id else ""
    extra = f": {extra_info}" if extra_info else ""
    
    if user_id:
        return f"[{message_type}] {user_info} в чате {chat_info}{extra}"
    else:
        return f"[{message_type}] Чат {chat_info}{extra}"

async def _delete_message_after_delay(bot: Bot, chat_id: int, message_id: int, delay: int):
    """Удаляет сообщение с указанной задержкой."""
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id, message_id)
        logger.debug(f"Сообщение {message_id} удалено из чата {chat_id} после задержки {delay} сек.")
    except TelegramAPIError as e:
        logger.warning(f"Не удалось удалить сообщение {message_id} из чата {chat_id}: {e}")

@group_msg_router.message(
    ~F.is_bot, # Игнорируем сообщения от других ботов
    F.text | F.photo | F.video | F.document | F.sticker | F.animation | F.voice | F.video_note # Реагируем на разные типы сообщений
)
async def handle_group_message(message: types.Message, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Основной обработчик сообщений в группах."""
    user = message.from_user
    chat = message.chat
    sender_chat = message.sender_chat # Получаем отправителя-чат
    msg_id = message.message_id # Получаем ID сообщения для логов

    chat_title = chat.title or f"Чат {chat.id}"
    user_name = user.full_name if user else "Неизвестный"
    
    logger.debug(format_log_message("GROUP_MSG", chat.id, chat_title, user.id if user else None, user_name, f"Получено сообщение (ID: {msg_id})"))

    # 0. Игнорируем сообщения от имени чата/канала
    if sender_chat:
        sender_chat_title = sender_chat.title or f"Чат {sender_chat.id}"
        logger.debug(format_log_message("GROUP_MSG", chat.id, chat_title, None, None, f"Сообщение от имени чата {sender_chat_title}, пропускаем"))
        return
        
    # Если нет sender_chat, проверяем пользователя
    if not user: # Сообщения без user и sender_chat (старые системные?)
        logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Сообщение без user и sender_chat, пропускаем.")
        return

    # 1. Проверка статуса пользователя (админ/создатель)
    sender_member = None
    try:
        sender_member = await bot.get_chat_member(chat.id, user.id)
        if sender_member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
            # Добавляем подробное логирование для сообщений админов/создателей
            admin_type = "админа" if sender_member.status == ChatMemberStatus.ADMINISTRATOR else "создателя"
            logger.info(format_log_message("ADMIN_MSG", chat.id, chat_title, user.id, user_name, 
                                 f"Получено сообщение от {admin_type} чата (ID: {msg_id})"))
            
            # Проверяем, есть ли текст в сообщении
            if message.text:
                text_preview = message.text[:50] + ("..." if len(message.text) > 50 else "")
                logger.info(format_log_message("ADMIN_MSG", chat.id, chat_title, user.id, user_name, 
                                   f"Текст сообщения: '{text_preview}'"))
            
            # Если у сообщения есть другие типы контента (фото, видео и т.д.)
            content_type = None
            if message.photo:
                content_type = "фото"
            elif message.video:
                content_type = "видео"
            elif message.document:
                content_type = "документ"
            elif message.sticker:
                content_type = "стикер"
            elif message.voice:
                content_type = "голосовое сообщение"
            
            if content_type:
                logger.info(format_log_message("ADMIN_MSG", chat.id, chat_title, user.id, user_name, 
                                   f"Тип контента: {content_type}"))
                
            return # Игнорируем дальнейшую обработку для админов и создателя
        else:
            logger.debug(format_log_message("GROUP_MSG", chat.id, chat_title, user.id, user_name, 
                                  f"Пользователь не админ (статус: {sender_member.status}). Продолжаем проверки"))
    except TelegramAPIError as e:
        logger.error(format_log_message("GROUP_MSG", chat.id, chat_title, user.id, user_name, 
                              f"Ошибка получения статуса: {e}. Пропускаем проверку"))

    # Инициализируем сервисы 
    captcha_service = CaptchaService(bot)
    subscription_service = SubscriptionService(bot, db_manager)
    logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Сервисы инициализированы.")

    # 2. Получение настроек чата
    chat_settings: Optional[Dict[str, Any]] = None
    try:
        chat_settings = await db_manager.get_chat_settings(chat.id)
        logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Настройки чата получены: {chat_settings}")
    except Exception as e:
        logger.error(f"[GROUP_MSG {chat.id}/{msg_id}] Ошибка БД при получении настроек: {e}. Пропускаем проверки.")
        return

    # 2.1 Проверка, завершена ли настройка для чата
    if not chat_settings or not chat_settings.get('setup_complete', False):
        logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Настройка чата НЕ завершена (setup_complete=False). Игнорируем сообщение.")
        return
    else:
        logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Настройка чата завершена (setup_complete=True).")

    # --- Дальнейшие проверки только если setup_complete == True ---
    
    user_status_db: Optional[Dict[str, Any]] = None
    try:
        user_status_db = await db_manager.get_user_status_in_chat(user.id, chat.id)
        logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Статус пользователя в БД: {user_status_db}")
    except Exception as e:
        logger.error(f"[GROUP_MSG {chat.id}/{msg_id}] Ошибка БД при получении user_status: {e}. Пропускаем проверки бана/капчи.")
        # В этом случае проверки бана и капчи, зависящие от статуса, не сработают
        # Но проверка подписки должна работать
        pass 
        
    # 3. Проверка бана (пропускаем, если не получили user_status_db)
    if user_status_db:
        # SQLite3.Row не имеет метода .get(), поэтому используем операции словаря
        if 'ban_until' in user_status_db:
            ban_until = user_status_db['ban_until']
            if ban_until and ban_until > int(time.time()):
                 logger.info(format_log_message("BAN_CHECK", chat.id, chat_title, user.id, user_name, f"Пользователь забанен до {ban_until}. Удаляем сообщение."))
                 try: await message.delete()
                 except TelegramAPIError as e: 
                     logger.warning(format_log_message("BAN_CHECK", chat.id, chat_title, user.id, user_name, f"Не удалось удалить сообщение: {e}"))
                 return # Прерываем
            else:
                 logger.debug(format_log_message("BAN_CHECK", chat.id, chat_title, user.id, user_name, "Пользователь не забанен"))
        else:
            logger.debug(format_log_message("BAN_CHECK", chat.id, chat_title, user.id, user_name, "Поле ban_until отсутствует"))
    else:
        logger.debug(format_log_message("BAN_CHECK", chat.id, chat_title, user.id, user_name, "Проверка бана пропущена (нет user_status_db)"))

    # 4. Проверка Капчи (если включена)
    captcha_enabled = chat_settings.get('captcha_enabled', False) # Используем только chat_settings
    logger.debug(format_log_message("CAPTCHA_CHECK", chat.id, chat_title, user.id, user_name, f"Проверка капчи включена: {captcha_enabled}"))
    
    # Убираем проверку капчи из обработчика обычных сообщений
    # Капча проверяется только один раз при вступлении пользователя в группу (в on_user_join)
    logger.debug(format_log_message("CAPTCHA_CHECK", chat.id, chat_title, user.id, user_name, "Капча проверяется только при вступлении в группу"))

    # 5. Проверка Подписки (если включена)
    subscription_check_enabled = chat_settings.get('subscription_check_enabled', False)
    logger.debug(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Проверка подписки включена: {subscription_check_enabled}"))
    if subscription_check_enabled:
        # Проверяем, что пользователь не админ и не владелец чата
        try:
            member_status = await bot.get_chat_member(chat.id, user.id)
            is_admin_or_creator = member_status.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]
            is_bot = user.is_bot
            
            if is_admin_or_creator:
                logger.info(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, "Пользователь является админом/создателем чата. Пропускаем проверку подписки"))
                return

            if is_bot:
                logger.info(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, "Пользователь является ботом. Пропускаем проверку подписки"))
                return  # Добавляем return, чтобы выйти из функции для ботов

            # Продолжаем только если пользователь обычный участник (не админ, не бот)
            logger.debug(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, "Запуск проверки подписки"))
            is_subscribed, not_subscribed_channels = await subscription_service.check_subscription(user.id, chat.id)
            
            # Получаем названия каналов для лога
            channel_info = []
            for channel_id in not_subscribed_channels:
                try:
                    channel = await bot.get_chat(channel_id)
                    channel_info.append(f"{channel.title} (ID: {channel_id})")
                except:
                    channel_info.append(f"ID: {channel_id}")
            
            channels_str = ", ".join(channel_info) if channel_info else "Нет"
            
            logger.debug(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Результат проверки: подписан={is_subscribed}, отсутствуют подписки: {channels_str}"))
            
            if not is_subscribed:
                logger.info(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Нет подписки на: {channels_str}. Удаление сообщения и отправка предупреждения"))
                # Удаляем сообщение пользователя
                try:
                    await message.delete()
                    logger.debug(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Сообщение {msg_id} удалено"))
                except Exception as e:
                    logger.warning(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Не удалось удалить сообщение {msg_id}: {e}"))
                
                # Отправляем предупреждение
                user_mention = get_user_link(user.id, user.full_name)
                is_admin = False  # Пользователь точно не админ (подтверждено проверкой выше)
                await subscription_service.send_subscription_warning(chat.id, user.id, user_mention, not_subscribed_channels, is_admin=is_admin)
                return
            else:
                logger.debug(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, "Подписан на все каналы"))
        except Exception as e:
            logger.error(format_log_message("SUB_CHECK", chat.id, chat_title, user.id, user_name, f"Ошибка при проверке статуса: {e}"))

    # Если все проверки пройдены
    logger.debug(f"[GROUP_MSG {chat.id}/{msg_id}] Сообщение от {user.id} прошло все проверки.")


# --- Обработка кода настройки (только от админов) --- #

@group_msg_router.message(
    F.text.startswith("setup_"), # Ловим только текст, начинающийся с setup_
    F.from_user.id != None # Убедимся, что есть ID пользователя 
)
async def handle_setup_code(message: types.Message, bot: Bot, db_manager: DatabaseManager, state: FSMContext):
    """Обрабатывает код настройки, отправленный админом."""
    user = message.from_user
    chat = message.chat

    # Проверяем, что отправитель - админ ЭТОГО чата
    try:
        sender_member = await bot.get_chat_member(chat.id, user.id)
        if sender_member.status not in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
            logger.info(f"[SETUP_CODE] Код '{message.text}' отправлен не админом ({user.id}) в чате {chat.id}. Игнорируем.")
            # Удаляем сообщение не-админа с кодом?
            try:
                await message.delete()
            except Exception:
                pass
            return
    except TelegramAPIError as e:
        logger.error(f"[SETUP_CODE] Ошибка проверки админа {user.id} при обработке кода: {e}")
        # Если не можем проверить, лучше не обрабатывать код
        return 

    # Пытаемся извлечь user_id из кода
    try:
        code_parts = message.text.split('_')
        if len(code_parts) != 2 or not code_parts[1].isdigit():
            raise ValueError("Неверный формат кода")
        user_id_from_code = int(code_parts[1])
    except ValueError:
        logger.warning(f"[SETUP_CODE] Неверный формат кода настройки '{message.text}' от админа {user.id} в чате {chat.id}.")
        # Уведомить админа об ошибке?
        try:
            await message.delete()
        except Exception:
            pass
        return

    logger.info(f"[SETUP_CODE] Админ {user.id} отправил код '{message.text}' для пользователя {user_id_from_code} в чате {chat.id} ('{chat.title}').")

    # Удаляем сообщение с кодом в группе
    try:
        await message.delete()
        logger.info(f"[SETUP_CODE] Сообщение с кодом от {user.id} удалено из чата {chat.id}.")
    except Exception as e:
        logger.warning(f"[SETUP_CODE] Не удалось удалить сообщение с кодом от {user.id} в чате {chat.id}: {e}. Продолжаем.")

    # Получаем FSM context для ЛС пользователя, которому предназначен код
    dp = Dispatcher.get_current()
    if not dp:
        logger.error("[SETUP_CODE] Не удалось получить текущий Dispatcher! FSM не запустится.")
        try:
            await bot.send_message(user.id, "Внутренняя ошибка (dispatcher). Настройка невозможна.")
        except Exception:
            pass
        return
    
    user_dm_state: FSMContext = dp.storage.get_context(bot=bot, chat_id=user_id_from_code, user_id=user_id_from_code)

    # Получаем объект User пользователя из кода
    try:
        target_user = await bot.get_chat(user_id_from_code)
        if target_user.type != ChatType.PRIVATE:
            logger.error(f"[SETUP_CODE] ID {user_id_from_code} из кода принадлежит не пользователю. Отмена.")
            try:
                await bot.send_message(user.id, f"Ошибка: ID {user_id_from_code} не является ID пользователя.")
            except Exception:
                pass
            return
    except TelegramAPIError as e:
        logger.error(f"[SETUP_CODE] Не удалось получить инфо о user {user_id_from_code}: {e}. Возможно, заблокировал бота.")
        try:
            await bot.send_message(user.id, f"Ошибка: не удалось найти user {user_id_from_code} или он заблокировал бота.")
        except Exception:
            pass
        return

    # Устанавливаем зависимости для сервиса (обязательно перед вызовом)
    channel_mgmt_service.bot = bot
    channel_mgmt_service.db = db_manager

    # Запускаем FSM в ЛС пользователя
    try:
        await channel_mgmt_service.start_channel_management_fsm(
            user=target_user, 
            chat_id_to_setup=chat.id,
            chat_title=chat.title or f"Чат ID {chat.id}",
            state=user_dm_state
        )
        logger.info(f"[SETUP_CODE] Успешно запущен FSM управления каналами для user {user_id_from_code} (админ {user.id}, чат {chat.id}).")
    except Exception as e:
        logger.error(f"[SETUP_CODE] Ошибка при запуске FSM для user {user_id_from_code}: {e}", exc_info=True)
        try:
            await bot.send_message(user.id, f"Произошла ошибка при запуске настройки для пользователя: {e}")
        except Exception:
            pass
        # Очищать ли state пользователя в ЛС? Наверное, да.
        await user_dm_state.clear()

# --- Обработка входа/выхода участников (оставляем как есть) --- #

@group_msg_router.chat_member(
    ChatMemberUpdatedFilter(IS_NOT_MEMBER >> IS_ADMIN)
)
@group_msg_router.chat_member(
    ChatMemberUpdatedFilter(IS_ADMIN >> IS_ADMIN)
)
async def on_admin_join_or_status_change(event: ChatMemberUpdated, bot: Bot, db_manager: DatabaseManager):
    """Реагирует на добавление админа или изменение статуса существующего.
       Также используется для начальной настройки при добавлении бота как админа.
    """
    chat_id = event.chat.id
    user_id = event.new_chat_member.user.id
    user_name = event.new_chat_member.user.first_name
    is_bot = event.new_chat_member.user.is_bot
    bot_info = await bot.get_me()

    logger.info(f"[ADMIN_EVENT] В чате {chat_id} изменился статус участника {user_id} ({user_name}). Новый статус: {event.new_chat_member.status.name}")

    # Если бот сам стал админом
    if user_id == bot_info.id:
        logger.info(f"[ADMIN_EVENT] Меня ({bot_info.username}) назначили админом в чате {chat_id} ({event.chat.title})")
        # При добавлении бота как админа, можно сразу создать запись о чате в БД
        # Это полезно, если бот был добавлен напрямую, а не через /setup
        await db_manager.add_chat_if_not_exists(
            chat_id=chat_id,
            chat_title=event.chat.title,
            added_by_user_id=event.from_user.id # Кто добавил/изменил права
        )
        # Можно отправить приветственное сообщение в чат о готовности к настройке
        try:
            await bot.send_message(
                chat_id,
                f"👋 Привет! Я готов к работе в чате {hbold(event.chat.title)}.\n"
                f"Администратор ({hlink(event.from_user.first_name, f'tg://user?id={event.from_user.id}')}) может теперь настроить меня.\n"
                f"Для начала получите код настройки в личных сообщениях со мной (@{bot_info.username}), используя команду /getcode, "
                f"а затем отправьте этот код сюда.",
                parse_mode="HTML",
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.warning(f"[ADMIN_EVENT] Не удалось отправить приветствие в чат {chat_id}: {e}")
    else:
        # Если изменился статус другого админа (не бота)
        # Здесь можно обновить список админов в БД, если это нужно
        logger.debug(f"[ADMIN_EVENT] Статус админа {user_id} ({user_name}) изменился в чате {event.chat.id}.")

# Обработка присоединения нового УЧАСТНИКА (не админа)
@group_msg_router.chat_member(
    ChatMemberUpdatedFilter(
        member_status_changed=(
            (F.status == ChatMemberStatus.KICKED) |
            (F.status == ChatMemberStatus.LEFT)
        ) >> (F.status == ChatMemberStatus.MEMBER)
    )
)
async def on_user_join(event: ChatMemberUpdated, bot: Bot, db_manager: DatabaseManager, captcha_service: CaptchaService, subscription_service: SubscriptionService):
    """Реагирует на вход нового пользователя (не админа) в группу."""
    chat = event.chat
    user = event.new_chat_member.user
    if user.is_bot: # Игнорируем других ботов
        return

    chat_title = chat.title or f"Чат {chat.id}"
    user_name = user.full_name

    logger.info(format_log_message("USER_JOIN", chat.id, chat_title, user.id, user_name, "Присоединился к чату"))
    
    # Очищаем кэш подписок при вступлении пользователя
    try:
        # Получаем каналы, связанные с чатом
        linked_channels = await db_manager.get_linked_channels_for_chat(chat.id)
        if linked_channels:
            # Импортируем переменную кэша
            from bot.services.subscription import _subscription_cache
            
            for channel_id in linked_channels:
                # Удаляем запись из кэша
                cache_key = (user.id, channel_id)
                if cache_key in _subscription_cache:
                    del _subscription_cache[cache_key]
                    logger.info(format_log_message("SUB_CACHE_CLEAR", chat.id, chat_title, user.id, user_name,
                                                  f"Очищен кэш подписки для канала {channel_id}"))
    except Exception as e:
        logger.warning(format_log_message("USER_JOIN", chat.id, chat_title, user.id, user_name, 
                                         f"Ошибка при очистке кэша подписок: {e}"))

    # 1. Проверяем настройки чата
    chat_settings = await db_manager.get_chat_settings(chat.id)
    if not chat_settings:
        logger.debug(f"[USER_JOIN] Настройки для чата {chat.id} не найдены. Пропускаем проверки.")
        return

    # 2. Проверка капчи при входе
    # Безопасный доступ к настройке captcha_on_join
    captcha_on_join = chat_settings and 'captcha_on_join' in chat_settings and chat_settings['captcha_on_join']
    if captcha_on_join:
        logger.info(format_log_message("CAPTCHA_TRIGGER", chat.id, chat_title, user.id, user_name, "Отправка капчи при входе в чат"))
        
        # Проверяем, пройдена ли уже капча в БД
        user_status = await db_manager.get_user_status_in_chat(user.id, chat.id)
        captcha_passed = user_status and user_status.get('captcha_passed', 0) if user_status else 0
        
        if captcha_passed:
            logger.info(format_log_message("CAPTCHA_TRIGGER", chat.id, chat_title, user.id, user_name, "Капча уже пройдена в БД, пропускаем отправку"))
        else:
            # Отправляем капчу
            await captcha_service.start_captcha_for_user(bot, chat.id, user.id)
            logger.info(format_log_message("CAPTCHA_TRIGGER", chat.id, chat_title, user.id, user_name, "Капча отправлена, ожидаем прохождения"))
            
        # Дальнейшая проверка подписки будет после прохождения капчи (если включена)
        return # Выходим, так как капча имеет приоритет
    else:
        logger.debug(format_log_message("CAPTCHA_TRIGGER", chat.id, chat_title, user.id, user_name, "Отправка капчи при входе отключена в настройках"))

    # 3. Проверка подписки при входе (если капча не включена или не нужна)
    # Безопасный доступ к настройке subscription_check_on_join
    subscription_on_join = chat_settings and 'subscription_check_on_join' in chat_settings and chat_settings['subscription_check_on_join']
    
    if subscription_on_join:
        # Дополнительно проверяем, что пользователь не админ
        try:
            # Используем event.new_chat_member вместо запроса к API, т.к. у нас уже есть статус
            is_admin_or_creator = event.new_chat_member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]
            
            if is_admin_or_creator:
                logger.info(f"[SUB_TRIGGER] Пользователь {user.id} является админом/создателем чата {chat.id}. Пропускаем проверку подписки.")
                return
                
            # Продолжаем только если обычный пользователь
            is_subscribed, not_subscribed_channels = await subscription_service.check_subscription(user.id, chat.id)
            
            # Получаем названия каналов для лога
            channel_info = []
            for channel_id in not_subscribed_channels:
                try:
                    channel = await bot.get_chat(channel_id)
                    channel_info.append(f"{channel.title} (ID: {channel_id})")
                except:
                    channel_info.append(f"ID: {channel_id}")
            
            channels_str = ", ".join(channel_info) if channel_info else "Нет"
            
            if not is_subscribed:
                logger.info(format_log_message("SUB_TRIGGER", chat.id, chat_title, user.id, user_name, f"Не подписан на: {channels_str}. Отправка предупреждения"))
                user_mention = get_user_link(user.id, user.full_name)
                is_admin = False  # Пользователь точно не админ (подтверждено проверкой выше)
                await subscription_service.send_subscription_warning(chat.id, user.id, user_mention, not_subscribed_channels, is_admin=is_admin)
                return
            else:
                logger.info(format_log_message("SUB_TRIGGER", chat.id, chat_title, user.id, user_name, "Подписан на все каналы"))
                # Здесь можно отправить приветственное сообщение, если нужно
        except Exception as e:
            logger.error(format_log_message("SUB_TRIGGER", chat.id, chat_title, user.id, user_name, f"Ошибка при проверке: {e}"))
            # В случае ошибки, пропускаем проверку для безопасности
            return
    else:
        # Если ничего не нужно проверять, можно просто выйти
        logger.debug(f"[USER_JOIN] Проверки отключены для пользователя {user.id} в чате {chat.id}")

# Убедитесь, что group_router импортирован и используется в основном файле бота (__main__.py)
# dp.include_router(group_router) 