import logging
import json
from aiogram import Router, Bot, F, types
from aiogram.filters import Command
from aiogram.enums import ChatType

from bot.db.database import DatabaseManager
# Импорт сервисов
from bot.services.channel_mgmt import ChannelManagementService
from bot.bot_instance import bot, db_manager
from bot.middlewares.db_middleware import DbSessionMiddleware
from bot.middlewares.bot_middleware import BotMiddleware
from bot.utils.helpers import is_admin

logger = logging.getLogger(__name__)
admin_router = Router()

# Регистрируем middleware
admin_router.message.middleware.register(DbSessionMiddleware(db_manager))
admin_router.callback_query.middleware.register(DbSessionMiddleware(db_manager))

admin_router.message.middleware.register(BotMiddleware(bot))
admin_router.callback_query.middleware.register(BotMiddleware(bot))

# Ограничиваем команды только для групповых чатов
admin_router.message.filter(F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}))

# --- Хелпер для проверки прав админа ---
async def check_admin_permissions(message: types.Message, bot: Bot) -> bool:
    if not await is_admin(bot, message.chat.id, message.from_user.id):
        await message.reply("Эта команда доступна только администраторам чата.")
        return False
    return True

# --- Команды управления каналами ---

@admin_router.message(Command("addchannel"))
async def add_channel_command(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    if not await check_admin_permissions(message, bot):
        return

    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply("Использование: /addchannel <ID канала или @username>")
        return

    channel_input = args[1]
    chat_id = message.chat.id

    try:
        # Попытка получить ID канала (работает и для ID, и для @username)
        target_channel = await bot.get_chat(channel_input)
        if target_channel.type != ChatType.CHANNEL:
            await message.reply("Указанный идентификатор не принадлежит каналу.")
            return
        channel_id = target_channel.id
    except Exception as e:
        logger.error(f"Ошибка получения информации о канале {channel_input}: {e}")
        await message.reply(f"Не удалось найти канал '{channel_input}'. Убедитесь, что ID или @username указаны верно, и бот добавлен в этот канал как администратор (если канал приватный).")
        return

    added = await db_manager.add_linked_channel(chat_id, channel_id)
    if added:
        await message.reply(f"Канал {target_channel.title} (ID: {channel_id}) успешно добавлен в список для проверки подписки.")
    else:
        await message.reply(f"Канал {target_channel.title} уже был в списке.")

@admin_router.message(Command("removechannel"))
async def remove_channel_command(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    if not await check_admin_permissions(message, bot):
        return

    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply("Использование: /removechannel <ID канала или @username>")
        return

    channel_input = args[1]
    chat_id = message.chat.id
    channel_id_to_remove = None

    # Пытаемся определить ID
    if channel_input.startswith('@') or channel_input.startswith('-100') or channel_input.isdigit():
         try:
             target_channel = await bot.get_chat(channel_input)
             if target_channel.type == ChatType.CHANNEL:
                 channel_id_to_remove = target_channel.id
             else:
                 await message.reply("Указанный идентификатор не принадлежит каналу.")
                 return
         except Exception as e:
             logger.warning(f"Не удалось проверить канал {channel_input} при удалении: {e}. Попытка удалить по строке.")
             # Если не удалось получить chat (например, бота там нет), попробуем удалить просто по ID, если он числовой
             if channel_input.startswith('-100') and channel_input[1:].isdigit():
                 channel_id_to_remove = int(channel_input)
             elif channel_input.isdigit():
                  channel_id_to_remove = int(channel_input) # Для публичных каналов может быть просто ID без -100

    if channel_id_to_remove is None:
         await message.reply(f"Не удалось распознать ID канала из '{channel_input}'. Укажите числовой ID или @username существующего канала.")
         return

    removed = await db_manager.remove_linked_channel(chat_id, channel_id_to_remove)
    if removed:
        await message.reply(f"Канал с ID {channel_id_to_remove} удален из списка проверки.")
    else:
        await message.reply(f"Канал с ID {channel_id_to_remove} не найден в списке.")


@admin_router.message(Command("listchannels"))
async def list_channels_command(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    if not await check_admin_permissions(message, bot):
        return

    chat_id = message.chat.id
    settings = await db_manager.get_chat_settings(chat_id)
    linked_ids = json.loads(settings['linked_channel_ids'] if settings else '[]')

    if not linked_ids:
        await message.reply("Список обязательных каналов для подписки пуст.")
        return

    response_lines = ["Обязательные каналы для подписки:"]
    for channel_id in linked_ids:
        try:
            channel_info = await bot.get_chat(channel_id)
            response_lines.append(f"- {channel_info.title} (<code>{channel_id}</code>)")
        except Exception:
            response_lines.append(f"- Не удалось получить информацию о канале <code>{channel_id}</code> (возможно, бот удален?)")

    await message.reply("\n".join(response_lines))


# --- Команды переключения настроек ---

@admin_router.message(Command("togglecaptcha"))
async def toggle_captcha_command(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    if not await check_admin_permissions(message, bot):
        return

    chat_id = message.chat.id
    new_state = await db_manager.toggle_setting(chat_id, 'captcha_enabled')
    if new_state is not None:
        status = "включена" if new_state else "выключена"
        await message.reply(f"✅ Проверка капчей для новых пользователей теперь {status}.")
    else:
        await message.reply("❌ Произошла ошибка при изменении настройки.")

@admin_router.message(Command("togglesubcheck"))
async def toggle_sub_check_command(message: types.Message, bot: Bot, db_manager: DatabaseManager):
    if not await check_admin_permissions(message, bot):
        return

    chat_id = message.chat.id
    new_state = await db_manager.toggle_setting(chat_id, 'subscription_check_enabled')
    if new_state is not None:
        status = "включена" if new_state else "выключена"
        await message.reply(f"✅ Проверка подписки на каналы теперь {status}.")
    else:
        await message.reply("❌ Произошла ошибка при изменении настройки.") 