import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from bot.services.subscription import SubscriptionService

logger = logging.getLogger(__name__)

class SubscriptionServiceMiddleware(BaseMiddleware):
    """Middleware для внедрения сервиса SubscriptionService в обработчики."""
    
    async def __call__(
        self, 
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Получаем объекты bot и db_manager из контекста, переданного другими middleware
        bot = data.get("bot")
        db_manager = data.get("db_manager")
        
        if not bot:
            logger.error("SubscriptionServiceMiddleware: bot не найден в контексте")
            return await handler(event, data)
            
        if not db_manager:
            logger.error("SubscriptionServiceMiddleware: db_manager не найден в контексте")
            return await handler(event, data)
        
        # Создаем экземпляр SubscriptionService и добавляем его в контекст
        subscription_service = SubscriptionService(bot, db_manager)
        data["subscription_service"] = subscription_service
        
        return await handler(event, data) 