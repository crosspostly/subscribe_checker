"""
Сервис для управления логикой капчи.
"""
import logging
import asyncio
from aiogram import Bot, types
from aiogram.exceptions import TelegramAPIError

from ..keyboards.inline import get_captcha_keyboard
from ..utils.helpers import get_user_mention_html

logger = logging.getLogger(__name__)

# Функция для форматирования логов капчи
def format_captcha_log(chat_id, chat_title, user_id, user_name, message, message_id=None):
    """Форматирует сообщения логов капчи с названиями чатов и пользователей."""
    user_info = f"{user_name} (ID: {user_id})" if user_name else f"Пользователь {user_id}"
    chat_info = f"{chat_title} (ID: {chat_id})" if chat_title else f"Чат {chat_id}"
    msg_info = f" (сообщение: {message_id})" if message_id else ""
    
    return f"[CAPTCHA] {user_info} в чате {chat_info}{msg_info}: {message}"

class CaptchaService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def send_captcha(self, message: types.Message):
        """Отправляет сообщение с капчей и удаляет исходное сообщение пользователя."""
        user = message.from_user
        chat_id = message.chat.id
        chat_title = message.chat.title or f"Чат {chat_id}"
        user_name = user.full_name
        user_mention = get_user_mention_html(user)

        try:
            # Удаляем исходное сообщение пользователя
            await message.delete()
            logger.debug(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                                    f"Удалено исходное сообщение", message.message_id))
        except TelegramAPIError as e:
            logger.warning(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                                    f"Не удалось удалить исходное сообщение: {e}", message.message_id))

        try:
            # Отправляем сообщение с капчей
            captcha_msg = await self.bot.send_message(
                chat_id,
                f"🛡️ {user_mention}, пожалуйста, подтвердите, что вы не робот, нажав кнопку ниже.",
                reply_markup=get_captcha_keyboard(user.id),
                parse_mode="HTML"
            )
            logger.info(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                                  f"Отправлена капча (будет активна 20 секунд)", captcha_msg.message_id))

            # Запускаем задачу на удаление капчи через 10 секунд
            asyncio.create_task(self._delete_message_after_delay(chat_id, chat_title, captcha_msg.message_id, 10, user.id, user_name))

        except TelegramAPIError as e:
            logger.error(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                                  f"Ошибка отправки капчи: {e}"))
            # Попытка удалить исходное сообщение, если отправка капчи не удалась (хотя выше уже пытались)
            # Это нужно, если удаление выше не сработало, а капча не отправилась.
            try:
                await message.delete()
            except TelegramAPIError:
                pass
        except Exception as e:
            logger.critical(format_captcha_log(chat_id, chat_title, user.id, user_name, 
                                     f"Непредвиденная ошибка при отправке капчи: {e}"))

    async def _delete_message_after_delay(self, chat_id: int, chat_title: str, message_id: int, delay: int, user_id: int = None, user_name: str = None):
        """Удаляет сообщение с указанной задержкой."""
        logger.debug(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                               f"Запланировано удаление капчи через {delay} секунд", message_id))
        await asyncio.sleep(delay)
        try:
            await self.bot.delete_message(chat_id, message_id)
            logger.debug(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                   f"Сообщение капчи удалено после задержки в {delay} секунд", message_id))
        except TelegramAPIError as e:
            # Ошибки удаления часто не критичны (сообщение могло быть удалено вручную или бот потерял права)
            logger.warning(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                    f"Не удалось удалить сообщение капчи: {e}", message_id))
            
    async def is_user_verified(self, user_id: int, chat_id: int, chat_title: str = None, user_name: str = None) -> bool:
        """Проверяет, прошел ли пользователь капчу в данном чате."""
        # Получаем DatabaseManager из зависимостей
        from bot.bot_instance import db_manager
        
        # Получаем статус пользователя в чате
        user_status = await db_manager.get_user_status_in_chat(user_id, chat_id)
        
        # Проверяем, прошел ли пользователь капчу
        captcha_passed = user_status and user_status['captcha_passed'] if user_status else 0
        
        status_str = "прошел" if captcha_passed else "не прошел"
        logger.debug(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                               f"Проверка статуса капчи: {status_str} (DB: {captcha_passed})"))
        return bool(captcha_passed)
        
    async def start_captcha_for_user(self, bot: Bot, chat_id: int, user_id: int):
        """Отправляет капчу при входе пользователя в чат."""
        try:
            # Получаем информацию о чате и пользователе для логов
            try:
                chat_info = await bot.get_chat(chat_id)
                chat_title = chat_info.title
            except:
                chat_title = f"Чат {chat_id}"
                
            try:
                user_info = await bot.get_chat(user_id)
                user_name = user_info.full_name
            except:
                user_name = f"Пользователь {user_id}"
                
            user_mention = f"<a href='tg://user?id={user_id}'>{user_name}</a>"
            
            # Перед отправкой капчи проверим статус в БД
            current_status = await self.is_user_verified(user_id, chat_id, chat_title, user_name)
            if current_status:
                logger.info(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                     f"Капча уже пройдена в БД, пропускаем отправку новой капчи"))
                return
                
            # Отправляем капчу
            captcha_msg = await bot.send_message(
                chat_id,
                f"🛡️ {user_mention}, пожалуйста, подтвердите, что вы не робот, нажав кнопку ниже.",
                reply_markup=get_captcha_keyboard(user_id),
                parse_mode="HTML"
            )
            logger.info(format_captcha_log(chat_id, chat_title, user_id, user_name, 
                                  f"Отправлена капча при входе в чат (будет активна 20 секунд)", captcha_msg.message_id))

            # Запускаем задачу на удаление капчи через 20 секунд
            asyncio.create_task(self._delete_message_after_delay(chat_id, chat_title, captcha_msg.message_id, 20, user_id, user_name))
        except Exception as e:
            logger.error(format_captcha_log(chat_id, None, user_id, None, 
                                  f"Ошибка отправки капчи при входе: {e}"))
