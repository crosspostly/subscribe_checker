"""
Сервис для управления каналами подписки через FSM.

Отвечает за логику сценариев:
- Добавление/удаление каналов после команды /getcode -> отправки кода в чат.
"""

import logging
import time
import asyncio
from typing import Union, List, Dict, Optional, Tuple

from aiogram import Bot, F, types
from aiogram.enums import ChatType, ChatMemberStatus
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError
from aiogram.fsm.context import FSMContext
from aiogram.types import (KeyboardButton, ReplyKeyboardMarkup, KeyboardButtonRequestChat,
                         ChatMemberUpdated, InlineKeyboardButton, InlineKeyboardMarkup)
from aiogram.utils.markdown import hbold, hlink, hitalic, hcode
from aiogram.fsm.storage.base import StorageKey, BaseStorage

# Используем абсолютные импорты
from bot.db.database import DatabaseManager
from bot.utils.helpers import get_user_mention_html
from bot.states import ManageChannels
from bot.keyboards.inline import get_channel_management_keyboard, get_channel_remove_keyboard

logger = logging.getLogger(__name__)

class ChannelManagementService:
    """Обрабатывает FSM логику для управления каналами подписки."""
    def __init__(self, bot: Bot, db_manager: DatabaseManager, storage: BaseStorage):
        self.bot = bot
        self.db = db_manager
        self.storage = storage # Сохраняем storage

    async def get_channel_title(self, channel_id: int) -> Optional[str]:
        try:
            chat = await self.bot.get_chat(channel_id)
            return chat.title if chat else None
        except Exception as e:
            logger.error(f"Error getting channel title for {channel_id}: {e}")
            return None

    async def check_bot_permissions(self, channel_id: int) -> bool:
        try:
            chat_member = await self.bot.get_chat_member(channel_id, self.bot.id)
            logger.info(f"Bot permissions in channel {channel_id}: {chat_member.status}")
            # Проверяем статус, а не просто наличие
            if not isinstance(chat_member, (types.ChatMemberAdministrator, types.ChatMemberOwner)):
                logger.warning(f"Bot is not an admin in channel {channel_id}, status: {chat_member.status}")
                return False
            # Дополнительно можно проверить конкретные права, если они важны (например, can_invite_users)
            # if isinstance(chat_member, types.ChatMemberAdministrator) and not chat_member.can_invite_users:
            #     logger.warning(f"Bot is admin in {channel_id} but lacks 'can_invite_users' permission.")
            #     # Возвращать False или True в зависимости от требований
            #     return True # Пока считаем, что достаточно быть админом
            return True
        except Exception as e:
            logger.error(f"Error checking bot permissions in channel {channel_id}: {e}")
            return False

    async def update_management_interface(self, user_id: int, state: FSMContext) -> None:
        try:
            state_data = await state.get_data()
            target_chat_id = state_data.get('target_chat_id')
            target_chat_title = state_data.get('target_chat_title', f"ID {target_chat_id}") # Получаем название чата
            current_channels = state_data.get('current_channels', [])
            # Сообщение, которое редактируем (если есть)
            message_id_to_edit = state_data.get('management_message_id')

            text_parts = [f"⚙️ Управление каналами для чата {hbold(target_chat_title)}\n"] # Используем название чата

            if not current_channels:
                text_parts.append("Список каналов для проверки пока пуст.")
            else:
                text_parts.append("Текущие каналы для проверки подписки:")
                channel_lines = []
                for i, channel in enumerate(current_channels):
                    ch_id = channel['id']
                    ch_title = channel.get('title', f'Канал ID {ch_id}') # Используем .get()
                    # Пытаемся сформировать ссылку, если ID похож на ID приватного канала
                    try:
                        if str(ch_id).startswith('-100'):
                           # Для приватных каналов ссылка формируется иначе и требует ID любого поста
                           # Простой link может не работать, используем title или ID
                           channel_link_text = ch_title
                        elif ch_title and not ch_title.startswith("Канал ID"):
                           # Для публичных каналов по title/username (если он есть)
                           # Это тоже не всегда username, может быть просто title
                           # Безопаснее просто показывать title
                           channel_link_text = ch_title
                        else: # Если title не получили или это просто ID
                           channel_link_text = f"Канал ID {ch_id}"
                        channel_lines.append(f"{i+1}. {channel_link_text}")
                    except Exception as e_link:
                        logger.warning(f"Ошибка формирования строки для канала {ch_id} ('{ch_title}'): {e_link}")
                        channel_lines.append(f"{i+1}. {ch_title or f'Канал ID {ch_id}'}")

                text_parts.extend(channel_lines)

            text = "\n".join(text_parts) + "\n\nВыберите действие:"

            # Используем новую клавиатуру управления
            keyboard = get_channel_management_keyboard(current_channels) # Передаем каналы для кнопок удаления

            send_method = self.bot.edit_message_text if message_id_to_edit else self.bot.send_message
            send_kwargs = {
                "chat_id": user_id,
                "text": text,
                "reply_markup": keyboard,
                "parse_mode": "HTML",
                "disable_web_page_preview": True # Отключаем превью ссылок
            }
            if message_id_to_edit:
                send_kwargs["message_id"] = message_id_to_edit
                logger.info(f"[FSM_MGMT] Редактируем интерфейс управления user={user_id}, msg_id={message_id_to_edit}")
            else:
                logger.info(f"[FSM_MGMT] Отправляем НОВЫЙ интерфейс управления user={user_id}")

            try:
                 sent_message = await send_method(**send_kwargs)
                 # Если отправили новое сообщение, сохраняем его ID для будущих редактирований
                 if not message_id_to_edit and sent_message:
                     await state.update_data(management_message_id=sent_message.message_id)
                     logger.debug(f"[FSM_MGMT] Сохранен ID сообщения интерфейса: {sent_message.message_id}")

            except TelegramAPIError as e:
                # Если не удалось отредактировать (например, сообщение слишком старое), пробуем отправить новое
                if "message to edit not found" in str(e) or "message is not modified" in str(e):
                    logger.warning(f"[FSM_MGMT] Не удалось отредактировать сообщение {message_id_to_edit}, отправляем новое. Ошибка: {e}")
                    await state.update_data(management_message_id=None) # Сбрасываем ID
                    sent_message = await self.bot.send_message(**send_kwargs) # Убираем message_id из kwargs
                    if sent_message:
                        await state.update_data(management_message_id=sent_message.message_id)
                else:
                    # Другая ошибка API
                    raise e # Передаем ее дальше

        except Exception as e:
            logger.error(f"[FSM_MGMT] Не удалось обновить интерфейс управления user={user_id}: {e}", exc_info=True)
            try:
                # Попытка отправить простое сообщение об ошибке
                await self.bot.send_message(user_id, "Не удалось отобразить интерфейс управления.", reply_markup=types.ReplyKeyboardRemove())
            except Exception:
                pass # Если и это не удалось, просто игнорируем

    async def start_channel_management(self, target_chat_id: int, target_chat_title: str, admin_user_id: int):
        """
        Инициирует FSM для управления каналами из команды /managechannels.
        Отправляет начальное сообщение с кнопками в ЛС админу.
        """
        # Создаем ключ и контекст FSM для пользователя в ЛС
        user_fsm_key = StorageKey(bot_id=self.bot.id, chat_id=admin_user_id, user_id=admin_user_id)
        state = FSMContext(storage=self.storage, key=user_fsm_key)
        
        # Очищаем предыдущее состояние на всякий случай
        await state.clear()

        logger.info(f"[MGMT_START] Инициация управления каналами для чата {target_chat_id} ('{target_chat_title}') админом {admin_user_id}.")

        try:
            # Получаем текущие каналы из БД
            linked_channel_ids = await self.db.get_linked_channels_for_chat(target_chat_id)
            logger.debug(f"[MGMT_START] Найденные каналы в БД для чата {target_chat_id}: {linked_channel_ids}")

            # Получаем их названия
            channel_tasks = [self.get_channel_title(ch_id) for ch_id in linked_channel_ids]
            channel_titles = await asyncio.gather(*channel_tasks)

            # Сохраняем начальные данные в state
            initial_channels_data = [
                {'id': ch_id, 'title': title or f"Канал ID {ch_id}"} # Используем ID, если название недоступно
                for ch_id, title in zip(linked_channel_ids, channel_titles)
            ]
            logger.debug(f"[MGMT_START] Сформированные данные каналов для state: {initial_channels_data}")

            await state.update_data(
                user_id=admin_user_id, # ID админа, который управляет
                target_chat_id=target_chat_id,
                target_chat_title=target_chat_title,
                current_channels=initial_channels_data, # Список словарей каналов
                is_management_session=True # Флаг, что это сессия редактирования
            )

            # Устанавливаем состояние
            await state.set_state(ManageChannels.managing_list)
            logger.info(f"[MGMT_START] Установлено состояние ManageChannels.managing_list для user={admin_user_id}")

            # Отправляем интерфейс управления в ЛС
            await self.update_management_interface(admin_user_id, state)

        except TelegramForbiddenError:
             logger.warning(f"[MGMT_START] Не удалось начать управление для user={admin_user_id} (бот заблокирован?).")
             await state.clear() # Очищаем состояние
        except Exception as e:
            logger.error(f"[MGMT_START] Ошибка при старте управления каналами для user={admin_user_id}, chat={target_chat_id}: {e}", exc_info=True)
            await state.clear()
            try:
                await self.bot.send_message(admin_user_id, "Произошла ошибка при запуске управления каналами. Попробуйте позже.", reply_markup=types.ReplyKeyboardRemove())
            except TelegramAPIError: pass # Не удалось даже отправить ошибку

    async def _ask_channel_selection(self, user_id: int, target_chat_id: int, message_to_edit: Optional[types.Message] = None):
        """Отправляет (или редактирует) сообщение с кнопкой выбора канала в ЛС."""
        prefix = "add"
        request_id = hash(f"{prefix}_{user_id}_{target_chat_id}_{time.time()}") % (2**31 - 1)
        select_channel_button = KeyboardButton(
            text="➡️ Выберите канал для добавления ⬅️",
            request_chat=KeyboardButtonRequestChat(
                request_id=request_id,
                chat_is_channel=True,
                bot_is_member=True # Убеждаемся, что бот есть в канале
                # bot_administrator_rights=types.ChatAdministratorRights(can_invite_users=True) # Можно добавить, если нужно
            )
        )
        # Убираем ReplyKeyboardRemove(), используем инлайн-кнопки или ничего
        keyboard = ReplyKeyboardMarkup(keyboard=[[select_channel_button]], resize_keyboard=True, one_time_keyboard=True)
        text = "Пожалуйста, нажмите кнопку ниже и выберите канал, который хотите добавить для проверки подписки."

        # Сохраняем request_id в state для проверки при получении chat_shared
        state = FSMContext(storage=self.storage, key=StorageKey(bot_id=self.bot.id, chat_id=user_id, user_id=user_id))
        await state.update_data(last_request_id=request_id) # Сохраняем ID запроса

        try:
            # Редактирование ReplyKeyboardMarkup не поддерживается, всегда отправляем новое сообщение
            # if message_to_edit:
            #     # Редактируем текст существующего сообщения (интерфейса)
            #     await self.bot.edit_message_text(chat_id=user_id, message_id=message_to_edit.message_id, text=text, reply_markup=keyboard)
            # else:
            #     # Отправляем новое сообщение
            #     await self.bot.send_message(user_id, text, reply_markup=keyboard)
            # Всегда отправляем новое сообщение для ReplyKeyboard
            await self.bot.send_message(user_id, text, reply_markup=keyboard)

            logger.info(f"[FSM_MGMT] Отправлен запрос выбора КАНАЛА (req_id={request_id}) user={user_id} для chat={target_chat_id}")

        except TelegramForbiddenError:
            logger.warning(f"[FSM_MGMT] Не удалось отправить ЛС user={user_id} (бот заблокирован?). Настройка прервана.")
            await state.clear() # Очищаем состояние
            # Пытаемся вернуть старый интерфейс, если было сообщение для редактирования
            if message_to_edit:
                try: await self.update_management_interface(user_id, state)
                except: pass
            raise # Передаем исключение выше
        except TelegramAPIError as e:
            logger.error(f"[FSM_MGMT] Ошибка API при запросе выбора канала user={user_id}: {e}")
            # Пытаемся вернуть старый интерфейс
            if message_to_edit:
                 try: await self.update_management_interface(user_id, state)
                 except: pass
            raise

    async def handle_add_more_channels_button(self, query: types.CallbackQuery, state: FSMContext):
        """Обработка кнопки 'Добавить еще канал'."""
        try:
            state_data = await state.get_data()
            target_chat_id = state_data.get('target_chat_id')
            if not target_chat_id:
                logger.error(f"[FSM_MGMT] Нет target_chat_id в состоянии user={query.from_user.id}")
                await query.answer("Ошибка: не найден ID чата. Начните сначала.")
                return

            await state.set_state(ManageChannels.adding_channel)
            await self._ask_channel_selection(query.from_user.id, target_chat_id, query.message)
            await query.answer()
        except Exception as e:
            logger.error(f"[FSM_MGMT] Ошибка при обработке кнопки добавления канала user={query.from_user.id}: {e}", exc_info=True)
            await query.answer("Произошла ошибка. Попробуйте позже.")
            await state.clear()

    async def handle_channel_select(self, message: types.Message, state: FSMContext):
        """Обрабатывает выбор канала через CHAT_SHARED."""
        user = message.from_user
        shared_chat_info = message.chat_shared
        selected_channel_id = shared_chat_info.chat_id
        request_id = shared_chat_info.request_id

        logger.info(f"[FSM_MGMT] Получен выбор канала user={user.id}: channel_id={selected_channel_id}, request_id={request_id}")

        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        if not target_chat_id:
            logger.error(f"[FSM_MGMT] КРИТ! Нет target_chat_id в состоянии user={user.id}, channel={selected_channel_id}. State: {state_data}")
            await message.reply("Внутренняя ошибка (нет ID чата). Начните сначала.", reply_markup=types.ReplyKeyboardRemove())
            await state.clear()
            return

        # Проверяем, не добавлен ли уже этот канал
        current_channels = state_data.get('current_channels', [])
        if any(ch['id'] == selected_channel_id for ch in current_channels):
            await message.reply("Этот канал уже добавлен в список.", reply_markup=types.ReplyKeyboardRemove())
            await state.set_state(ManageChannels.managing_list)
            await self.update_management_interface(user.id, state)
            return

        # Проверяем права бота в канале
        has_permissions = await self.check_bot_permissions(selected_channel_id)
        if not has_permissions:
            await message.reply("⚠️ У меня нет доступа к этому каналу.", reply_markup=types.ReplyKeyboardRemove())
            await state.set_state(ManageChannels.managing_list)
            await self.update_management_interface(user.id, state)
            return

        # Получаем название канала
        channel_title = await self.get_channel_title(selected_channel_id)

        # Добавляем канал в список
        current_channels.append({'id': selected_channel_id, 'title': channel_title})
        await state.update_data(current_channels=current_channels)

        # Обновляем интерфейс
        await state.set_state(ManageChannels.managing_list)
        await self.update_management_interface(user.id, state)

    async def handle_wrong_channel_select(self, message: types.Message, state: FSMContext):
        """Ловит любые другие сообщения в состоянии ожидания выбора канала."""
        user = message.from_user
        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        logger.warning(f"[FSM_MGMT] Неверный ввод от user={user.id} в состоянии waiting_for_channel_select: {message.text[:50]}...")
        await message.reply("Пожалуйста, используйте <b>кнопку</b> ниже, чтобы выбрать канал.", parse_mode="HTML")
        # Повторно отправляем запрос
        if target_chat_id:
            try:
                await self._ask_channel_selection(user.id, target_chat_id)
            except Exception:
                await message.answer("Произошла ошибка при повторном запросе выбора канала.")
                await state.clear()
        else:
             await message.answer("Критическая ошибка: не найден ID чата. Начните сначала.")
             await state.clear()

    # --- Обработчики кнопок интерфейса управления --- #

    async def handle_remove_channel_start(self, query: types.CallbackQuery, state: FSMContext):
        """Обработка кнопки 'Удалить канал'. Показывает клавиатуру с каналами."""
        user_id = query.from_user.id
        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        current_channels = state_data.get('current_channels', [])

        logger.info(f"[FSM_MGMT] user={user_id} нажал 'Удалить' для chat={target_chat_id}")

        if not target_chat_id:
            logger.error(f"[FSM_MGMT] Нет target_chat_id при нажатии 'Удалить' user={user_id}")
            await query.message.edit_text("Ошибка: не найден ID чата. Начните сначала.")
            await state.clear()
            return
        if not current_channels:
             logger.warning(f"[FSM_MGMT] Нет каналов для удаления user={user_id}, chat={target_chat_id}")
             await query.answer("Нет добавленных каналов для удаления.", show_alert=True)
             return # Остаемся в том же состоянии

        # Переходим в состояние ожидания выбора канала для удаления
        await state.set_state(ManageChannels.waiting_for_channel_remove)

        # Формируем клавиатуру для удаления
        remove_keyboard = get_channel_remove_keyboard(current_channels)

        try:
            await query.message.edit_text("Выберите канал, который хотите удалить из списка:", reply_markup=remove_keyboard)
            logger.info(f"[FSM_MGMT] Показана клавиатура удаления для user={user_id}, chat={target_chat_id}")
        except TelegramAPIError as e:
            logger.error(f"[FSM_MGMT] Ошибка при показе клавиатуры удаления user={user_id}: {e}")
            # Возвращаемся к основному интерфейсу
            await state.set_state(ManageChannels.managing_list)
            await self.update_management_interface(user.id, state)
            await query.answer("Ошибка отображения списка для удаления.", show_alert=True)

        await query.answer() # Закрываем часики у кнопки "Удалить"

    async def handle_remove_channel_confirm(self, query: types.CallbackQuery, callback_data: Dict, state: FSMContext):
        """Обработка нажатия на кнопку с каналом для удаления."""
        user_id = query.from_user.id
        channel_id_to_remove = int(callback_data['channel_id']) # CallbackData хранит ID как строку?

        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        current_channels: List[Dict] = state_data.get('current_channels', [])

        logger.info(f"[FSM_MGMT] user={user_id} выбрал удалить канал {channel_id_to_remove} для chat={target_chat_id}")

        removed_channel_title = f"ID {channel_id_to_remove}"
        new_channels_list = []
        found = False
        for ch_data in current_channels:
            if ch_data['id'] == channel_id_to_remove:
                removed_channel_title = ch_data.get('title', removed_channel_title)
                found = True
            else:
                new_channels_list.append(ch_data)

        if found:
            await state.update_data(current_channels=new_channels_list)
            logger.info(f"[FSM_MGMT] Канал {channel_id_to_remove} ('{removed_channel_title}') временно удален user={user_id}, chat={target_chat_id}")
            await query.answer(f"Канал '{removed_channel_title}' удален из списка.")
        else:
            logger.warning(f"[FSM_MGMT] Канал {channel_id_to_remove} не найден в state для удаления user={user_id}, chat={target_chat_id}")
            await query.answer("Этот канал уже был удален.", show_alert=True)

        # Возвращаемся к основному интерфейсу управления
        await state.set_state(ManageChannels.managing_list)
        await self.update_management_interface(user.id, state)

    async def handle_cancel_channel_removal(self, query: types.CallbackQuery, state: FSMContext):
        """Обработка кнопки 'Отмена' на экране удаления канала."""
        user_id = query.from_user.id
        logger.info(f"[FSM_MGMT] user={user_id} отменил удаление канала.")
        await query.answer("Отмена удаления.")
        # Возвращаемся к основному интерфейсу управления
        await state.set_state(ManageChannels.managing_list)
        await self.update_management_interface(query.message.chat.id, state)

    async def handle_finish_channel_management(self, query: types.CallbackQuery, state: FSMContext):
        """Обработка кнопки 'Готово'. Сохраняет изменения в БД."""
        user_id = query.from_user.id
        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id')
        target_chat_title = state_data.get('target_chat_title', '???')
        final_channels: List[Dict] = state_data.get('current_channels', [])
        final_channel_ids = [ch['id'] for ch in final_channels]

        logger.info(f"[FSM_MGMT] user={user_id} нажал 'Готово' для chat={target_chat_id}. Финальный список ID: {final_channel_ids}")

        if not target_chat_id:
            logger.error(f"[FSM_MGMT] Нет target_chat_id при нажатии 'Готово' user={user_id}")
            await query.message.edit_text("Ошибка: не найден ID чата. Начните сначала.")
            await state.clear()
            return

        try:
            # 1. Получаем текущие связи из БД
            existing_channel_ids_db = set(await self.db.get_linked_channels_for_chat(target_chat_id))
            logger.debug(f"[FSM_MGMT] Каналы в БД перед сохранением: {existing_channel_ids_db}")
            
            # 2. Получаем желаемые связи из state
            desired_channel_ids_state = set(final_channel_ids)
            logger.debug(f"[FSM_MGMT] Желаемые каналы из state: {desired_channel_ids_state}")
            
            # 3. Определяем, что добавить, а что удалить
            channels_to_add = desired_channel_ids_state - existing_channel_ids_db
            channels_to_remove = existing_channel_ids_db - desired_channel_ids_state
            
            logger.info(f"[FSM_MGMT] Каналы к добавлению: {channels_to_add}")
            logger.info(f"[FSM_MGMT] Каналы к удалению: {channels_to_remove}")

            # 4. Удаляем ненужные связи
            if channels_to_remove:
                for channel_id in channels_to_remove:
                    await self.db.remove_linked_channel(target_chat_id, channel_id)
                logger.info(f"[FSM_MGMT] Удалены связи для каналов: {channels_to_remove}")
            
            # 5. Добавляем новые связи
            if channels_to_add:
                for channel_id in channels_to_add:
                    await self.db.add_linked_channel(target_chat_id, channel_id, user_id)
                logger.info(f"[FSM_MGMT] Добавлены связи для каналов: {channels_to_add}")

            # 6. Получаем и обновляем общие настройки чата (включая флаг подписки)
            # Флаг подписки зависит от итогового состояния (desired_channel_ids_state)
            subscription_check_enabled = 1 if desired_channel_ids_state else 0
            
            # Обновляем настройки в БД
            await self.db.update_chat_settings(
                chat_id=target_chat_id, 
                settings={
                    'subscription_check_enabled': subscription_check_enabled,
                    'configured_by_user_id': user_id, # Обновляем, кто последний раз менял
                    'setup_complete': 1 # Устанавливаем флаг завершения настройки здесь
                } 
            )
            # Удаляем отдельный запрос на обновление setup_complete
            # await self.db._execute(
            #     "UPDATE chats SET setup_complete = 1 WHERE chat_id = ?",
            #     (target_chat_id,),
            #     commit=True
            # )

            success_text = f"✅ Настройка каналов для чата {hbold(target_chat_title)} успешно сохранена!\n"
            if desired_channel_ids_state:
                success_text += f"Проверка подписки на {len(desired_channel_ids_state)} канал(а/ов) включена."
            else:
                success_text += "Список каналов пуст, проверка подписки отключена."

            await query.message.edit_text(success_text, parse_mode="HTML")
            logger.info(f"[FSM_MGMT] Настройки чата {target_chat_id} сохранены user={user_id}")
            await state.clear() # Завершаем FSM

        except Exception as e:
            logger.error(f"[FSM_MGMT] Ошибка БД при сохранении настроек chat={target_chat_id} user={user_id}: {e}", exc_info=True) # Добавил exc_info
            await query.answer("Ошибка при сохранении настроек. Попробуйте завершить настройку еще раз.", show_alert=True) # show_alert=True
            # Не редактируем сообщение, чтобы пользователь видел предыдущее состояние
            # await query.message.edit_text("Произошла ошибка при сохранении настроек. Попробуйте завершить настройку еще раз.")
            # Очищаем состояние, чтобы избежать зацикливания
            await state.clear() 
        
        # Убираем query.answer() здесь, он вызывается в блоке try или except
        # await query.answer()

    async def handle_cancel_channel_management(self, query: types.CallbackQuery, state: FSMContext):
        """Обработка кнопки 'Отмена' в главном интерфейсе."""
        user_id = query.from_user.id
        state_data = await state.get_data()
        target_chat_id = state_data.get('target_chat_id', '???')
        logger.info(f"[FSM_MGMT] user={user_id} отменил настройку каналов для chat={target_chat_id}")
        await state.clear()
        await query.answer("Настройка отменена.")
        try:
            await query.message.edit_text("Настройка каналов отменена.")
        except TelegramAPIError:
            pass # Игнорируем, если сообщение уже было изменено 