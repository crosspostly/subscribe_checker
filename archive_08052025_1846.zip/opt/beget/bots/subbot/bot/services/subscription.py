"""
Сервис для проверки подписки пользователя на каналы, связанные с чатом.
"""
import logging
import asyncio
import json
from typing import List, Tuple, Dict, Any, Optional, Union
import time # Для TTL кэша
import datetime

from aiogram import Bot, types
from aiogram.enums import ChatMemberStatus
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, Chat
from aiogram.utils.markdown import hlink

from ..db.database import DatabaseManager
from ..utils.helpers import get_user_mention_html

logger = logging.getLogger(__name__)

# --- Кэш для информации о чатах --- #
_chat_info_cache = {}
_CACHE_TTL = 300 # Время жизни кэша в секундах (5 минут)

# Кэш для результатов проверки подписки пользователей
_subscription_cache = {}  # {(user_id, channel_id): {"result": bool, "timestamp": time}}
_SUBSCRIPTION_CACHE_TTL = 86400  # 24 часа

# Функция для форматирования ссылок на чаты и пользователей
def get_chat_link_for_md(chat_id, chat_title=None):
    """Создает ссылку на чат в формате Markdown"""
    if not chat_title:
        chat_title = f"Чат {chat_id}"
    # Убираем -100 из ID чата для корректной ссылки
    link_id = str(chat_id).replace('-100', '')
    return f"[{chat_title}](https://t.me/c/{link_id})"

def get_user_link_for_md(user_id, user_name=None):
    """Создает ссылку на пользователя в формате Markdown"""
    if not user_name:
        user_name = f"Пользователь {user_id}"
    return f"[{user_name}](tg://user?id={user_id})"

# Функция форматирования сообщений для лога
def format_sub_log(message_type: str, user_id: Optional[int] = None, 
                  user_name: Optional[str] = None, 
                  chat_id: Optional[int] = None, 
                  chat_title: Optional[str] = None, 
                  extra_info: Optional[str] = None):
    """Форматирует сообщение для логов с красивыми названиями вместо ID"""
    user_part = f"{user_name or 'Unknown'} (ID: {user_id})" if user_id else ""
    chat_part = f"{chat_title or f'Чат {chat_id}'} (ID: {chat_id})" if chat_id else ""
    details = f": {extra_info}" if extra_info else ""
    
    if user_id and chat_id:
        return f"[{message_type}] {user_part} в {chat_part}{details}"
    elif user_id:
        return f"[{message_type}] {user_part}{details}"
    elif chat_id:
        return f"[{message_type}] {chat_part}{details}"
    else:
        return f"[{message_type}]{details}"

# Получение информации о чате с кэшированием
async def get_cached_chat_info(bot: Bot, chat_id: int, force_refresh: bool = False) -> Optional[Any]:
    """Получает информацию о чате с кэшированием."""
    current_time = asyncio.get_event_loop().time()
    
    # Проверяем кэш и его срок годности (30 минут)
    if not force_refresh and chat_id in _chat_info_cache:
        cache_entry = _chat_info_cache[chat_id]
        # Если кэш не старше 30 минут, используем его
        if current_time - cache_entry.get('timestamp', 0) < 1800:  # 30 минут = 1800 секунд
            return cache_entry.get('info')
    
    # Кэш отсутствует или устарел, запрашиваем информацию
    try:
        chat_info = await bot.get_chat(chat_id)
        # Обновляем кэш
        _chat_info_cache[chat_id] = {'info': chat_info, 'timestamp': current_time}
        return chat_info
    except Exception as e:
        logger.error(f"[CHAT_INFO] Не удалось получить информацию о чате {chat_id}: {e}")
        # В случае ошибки обнуляем кэш для этого чата
        _chat_info_cache[chat_id] = {'info': None, 'timestamp': current_time} 
        return None

# Функции для работы с кэшем подписок
def get_cached_subscription(user_id: int, channel_id: int) -> Tuple[bool, bool]:
    """
    Получает результат проверки подписки из кэша
    Возвращает (is_cached, is_member)
    """
    cache_key = (user_id, channel_id)
    current_time = time.time()
    
    if cache_key in _subscription_cache:
        entry = _subscription_cache[cache_key]
        # Проверяем TTL
        if current_time - entry["timestamp"] < _SUBSCRIPTION_CACHE_TTL:
            # Кэш актуален
            return True, entry["result"]
    
    # Кэша нет или он устарел
    return False, False

def set_subscription_cache(user_id: int, channel_id: int, is_member: bool):
    """Сохраняет результат проверки подписки в кэш"""
    cache_key = (user_id, channel_id)
    _subscription_cache[cache_key] = {
        "result": is_member,
        "timestamp": time.time()
    }

def update_subscription_cache(user_id: int, channel_id: int, is_member: bool = True):
    """
    Принудительно обновляет кэш подписки пользователя.
    Используется когда мы точно знаем, что пользователь подписался на канал.
    """
    cache_key = (user_id, channel_id)
    _subscription_cache[cache_key] = {
        "result": is_member,
        "timestamp": time.time()
    }
    logger.info(f"[SUB_CACHE_UPDATE] 🔵 Принудительно обновлен кэш для пользователя {user_id} на канал {channel_id}: подписан={is_member}")

# Очистка старых записей из кэша (запускается периодически)
def clear_expired_subscription_cache():
    """Удаляет устаревшие записи из кэша подписок"""
    current_time = time.time()
    expired_keys = []
    
    for key, entry in _subscription_cache.items():
        if current_time - entry["timestamp"] > _SUBSCRIPTION_CACHE_TTL:
            expired_keys.append(key)
    
    for key in expired_keys:
        del _subscription_cache[key]
    
    if expired_keys:
        logger.debug(f"[SUB_CACHE] Очищено {len(expired_keys)} устаревших записей из кэша подписок")

# ----------------------------------- #

class SubscriptionService:
    def __init__(self, bot: Bot, db_manager: DatabaseManager):
        self.bot = bot
        self.db = db_manager
        # Запускаем периодическую очистку кэша (каждые 10 минут)
        asyncio.create_task(self._schedule_cache_cleanup())
        # Запускаем ежедневное обновление кэша в 5 утра
        asyncio.create_task(self.schedule_daily_cache_update())

    async def _schedule_cache_cleanup(self):
        """Запускает периодическую очистку кэша"""
        while True:
            await asyncio.sleep(600)  # 10 минут
            clear_expired_subscription_cache()
            
    async def schedule_daily_cache_update(self):
        """Запускает ежедневное обновление кэша подписок в 5 утра"""
        while True:
            try:
                # Вычисляем время до 5 утра
                now = datetime.datetime.now()
                target_time = now.replace(hour=5, minute=0, second=0, microsecond=0)
                if now >= target_time:
                    # Если сейчас после 5 утра, планируем на завтра
                    target_time = target_time + datetime.timedelta(days=1)
                
                # Ждем до 5 утра
                seconds_to_wait = (target_time - now).total_seconds()
                logger.info(f"[CACHE_SCHEDULER] 📆 Запланировано обновление кэша подписок в {target_time.strftime('%Y-%m-%d %H:%M:%S')} (через {seconds_to_wait/3600:.1f} часов)")
                await asyncio.sleep(seconds_to_wait)
                
                # Обновляем кэш для всех активных пользователей
                await self.update_all_subscriptions_cache()
                logger.info(f"[CACHE_SCHEDULER] ✅ Выполнено массовое обновление кэша подписок")
            except Exception as e:
                logger.error(f"[CACHE_SCHEDULER] ❌ Ошибка в планировщике: {e}", exc_info=True)
                await asyncio.sleep(3600)  # При ошибке повторная попытка через час

    async def update_all_subscriptions_cache(self):
        """Обновляет кэш подписок для всех активных пользователей и каналов"""
        try:
            # Получаем все активные чаты с включенной проверкой подписки
            active_chats = await self.db.get_active_chats_with_subscription_check()
            total_chats = len(active_chats)
            total_users = 0
            total_channels = 0
            total_checks = 0
            
            logger.info(f"[CACHE_UPDATE] 🔄 Начато массовое обновление кэша для {total_chats} чатов")
            
            # Для каждого чата получаем список активных пользователей и связанных каналов
            for chat_id in active_chats:
                # Получаем каналы, связанные с чатом
                linked_channels = await self.db.get_linked_channels_for_chat(chat_id)
                if not linked_channels:
                    logger.debug(f"[CACHE_UPDATE] Чат {chat_id} не имеет связанных каналов, пропускаем")
                    continue
                    
                # Получаем активных пользователей чата (например, писавших за последние 7 дней)
                active_users = await self.db.get_active_chat_users(chat_id, days=7)
                if not active_users:
                    logger.debug(f"[CACHE_UPDATE] Чат {chat_id} не имеет активных пользователей за последние 7 дней, пропускаем")
                    continue
                
                total_users += len(active_users)
                total_channels += len(linked_channels)
                
                # Проверяем подписку для каждого пользователя на все каналы
                logger.info(f"[CACHE_UPDATE] Обрабатываю чат {chat_id}: {len(active_users)} пользователей × {len(linked_channels)} каналов")
                
                for user_id in active_users:
                    for channel_id in linked_channels:
                        try:
                            # Делаем прямой запрос к API Telegram
                            member = await self.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
                            is_member = member.status in {ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
                            
                            # Обновляем кэш
                            _subscription_cache[(user_id, channel_id)] = {
                                "result": is_member,
                                "timestamp": time.time()
                            }
                            
                            total_checks += 1
                            status_value = member.status.value if hasattr(member.status, 'value') else str(member.status)
                            
                            if total_checks % 100 == 0:  # Логируем каждые 100 проверок
                                logger.info(f"[CACHE_UPDATE] Обработано {total_checks} проверок подписок")
                                
                        except Exception as e:
                            logger.error(f"[CACHE_UPDATE] Ошибка при обновлении кэша для пользователя {user_id} и канала {channel_id}: {e}")
                            
            logger.info(f"[CACHE_UPDATE] ✅ Завершено обновление кэша: {total_chats} чатов, {total_users} пользователей, {total_channels} каналов, {total_checks} проверок")
            
        except Exception as e:
            logger.error(f"[CACHE_UPDATE] ❌ Ошибка при массовом обновлении кэша: {e}", exc_info=True)
            
    async def check_single_channel(self, user_id: int, channel_id: int, user_name: str = None) -> Tuple[int, Any]:
        """
        Проверяет подписку пользователя на один канал с использованием кэша
        Возвращает (channel_id, статус)
        """
        # Сначала проверяем кэш
        is_cached, cached_result = get_cached_subscription(user_id, channel_id)
        
        if is_cached:
            # Используем результат из кэша
            logger.debug(format_sub_log("SUB_CACHE", user_id=user_id, user_name=user_name, 
                                       extra_info=f"Найден кэш для канала {channel_id}: подписан={cached_result}"))
            return channel_id, ChatMemberStatus.MEMBER if cached_result else "not_subscribed"
        
        # Если нет в кэше, делаем запрос к API
        try:
            member = await self.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            
            # Определяем результат
            is_member = member.status in {ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
            
            # Получаем информацию о канале для логов
            channel_info = await get_cached_chat_info(self.bot, channel_id)
            channel_title = channel_info.title if channel_info else f"Канал {channel_id}"
            
            # ПОДРОБНОЕ ЛОГИРОВАНИЕ ДЛЯ НОВЫХ ПОДПИСЧИКОВ
            status_text = "ПОДПИСАН" if is_member else "НЕ ПОДПИСАН"
            status_value = member.status.value if hasattr(member.status, 'value') else str(member.status)
            logger.info(format_sub_log("SUB_NEW_CHECK", user_id=user_id, user_name=user_name, 
                                      extra_info=f"👉 Пользователь {status_text} на {channel_title} (ID: {channel_id}), статус: {status_value}"))
            
            # Сохраняем в кэш
            set_subscription_cache(user_id, channel_id, is_member)
            
            return channel_id, member.status
        except TelegramAPIError as e:
            if "user not found" in str(e).lower():
                # Пользователь не найден в канале
                logger.info(format_sub_log("SUB_NEW_CHECK", user_id=user_id, user_name=user_name, 
                                          extra_info=f"❌ Пользователь НЕ НАЙДЕН в канале {channel_id}: {e}"))
                set_subscription_cache(user_id, channel_id, False)
                return channel_id, "not_found"
            else:
                logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                          extra_info=f"Ошибка API при проверке канала {channel_id}: {e}"))
                return channel_id, "api_error"
        except Exception as e:
            logger.critical(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                         extra_info=f"Непредвиденная ошибка для канала {channel_id}: {e}"), exc_info=True)
            return channel_id, "unknown_error"

    async def check_subscription(self, user_id: int, chat_id: int) -> Tuple[bool, List[int]]:
        """
        Проверяет подписку пользователя на все каналы, связанные с чатом.
        
        Args:
            user_id: ID пользователя
            chat_id: ID чата
            
        Returns:
            (is_subscribed, missing_channel_ids): кортеж из флага подписки и списка ID каналов, на которые не подписан
        """
        settings = await self.db.get_chat_settings(chat_id)
        user_info = await self.bot.get_chat_member(chat_id, user_id)
        user_name = user_info.user.full_name if user_info and user_info.user else "Неизвестный"
        chat_info = await get_cached_chat_info(self.bot, chat_id)
        chat_title = chat_info.title if chat_info else f"Чат {chat_id}"
        
        logger.info(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                               chat_id=chat_id, chat_title=chat_title,
                               extra_info=f"Проверка подписки запущена"))
        
        if not settings or not settings['subscription_check_enabled']:
            logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                    chat_id=chat_id, chat_title=chat_title,
                                    extra_info=f"Проверка подписки отключена в настройках чата"))
            return True, []
                                    
        # Получаем список каналов, связанных с чатом
        linked_channels = await self.db.get_linked_channels_for_chat(chat_id)
        
        if not linked_channels:
            logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                    chat_id=chat_id, chat_title=chat_title,
                                    extra_info=f"Нет связанных каналов для проверки"))
            return True, []
            
        # Проверяем подписку пользователя на каждый канал
        not_subscribed_channels = []
        
        # ВАЖНО: Очищаем кэш перед проверкой для всех каналов
        for channel_id in linked_channels:
            # Удаляем запись из кэша, чтобы проверка была свежей
            cache_key = (user_id, channel_id)
            if cache_key in _subscription_cache:
                del _subscription_cache[cache_key]
                logger.info(format_sub_log("SUB_CACHE_CLEAR", user_id=user_id, user_name=user_name,
                                          extra_info=f"🧹 Очищен кэш подписки для канала {channel_id}"))
        
        # Функция для проверки отдельного канала
        async def check_channel(channel_id):
            """Проверяет подписку на один канал и возвращает (channel_id, статус)"""
            # ИЗМЕНЕНИЕ: Убираем кэш и всегда делаем прямую проверку API
            # is_cached, is_subscribed = get_cached_subscription(user_id, channel_id)
            
            # ВАЖНО: Всегда делаем прямой запрос к API, так как пользователь утверждает, 
            # что он подписан, но бот всё равно удаляет сообщения
            try:
                member = await self.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
                is_subscribed = member.status in {ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
                
                # Обновляем кэш ПОСЛЕ проверки реального статуса
                set_subscription_cache(user_id, channel_id, is_subscribed)
                
                # Получаем информацию о канале для логов
                channel_info = await get_cached_chat_info(self.bot, channel_id)
                channel_title = channel_info.title if channel_info else f"Канал {channel_id}"
                
                status_text = "ПОДПИСАН" if is_subscribed else "НЕ ПОДПИСАН"
                status_value = member.status.value if hasattr(member.status, 'value') else str(member.status)
                logger.info(format_sub_log("SUB_CHECK_DIRECT", user_id=user_id, user_name=user_name, 
                                      extra_info=f"👉 Пользователь {status_text} на {channel_title} (ID: {channel_id}), статус: {status_value}"))
                
                return channel_id, is_subscribed
            except Exception as e:
                logger.error(format_sub_log("SUB_CHECK_DIRECT", user_id=user_id, user_name=user_name, 
                                      extra_info=f"❌ Ошибка при прямой проверке канала {channel_id}: {e}"), exc_info=True)
                # В случае ошибки возвращаем, что пользователь не подписан
                return channel_id, False
        
        # Выполняем проверку всех каналов параллельно
        tasks = [check_channel(channel_id) for channel_id in linked_channels]
        results = await asyncio.gather(*tasks)
        
        # Обрабатываем результаты
        for channel_id, is_subscribed in results:
            if not is_subscribed:
                not_subscribed_channels.append(channel_id)
                channel_info = await get_cached_chat_info(self.bot, channel_id)
                logger.info(format_sub_log("SUB_CHECK_GATHER", user_id=user_id, user_name=user_name, 
                                       extra_info=f"Не подписан на {channel_info.title if channel_info else f'канал {channel_id}'} (ID: {channel_id})"))
        
        # Обновляем статус пользователя в БД
        current_time = int(time.time())
        try:
            await self.db.update_user_subscription_status(
                chat_id=chat_id, 
                user_id=user_id, 
                is_subscribed=(len(not_subscribed_channels) == 0),
                timestamp=current_time
            )
            logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                    extra_info=f"Статус подписки обновлен в БД: {'подписан' if len(not_subscribed_channels) == 0 else 'не подписан'}"))
        except Exception as e:
            logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name, 
                                    extra_info=f"Ошибка при обновлении статуса в БД: {e}"))
        
        return len(not_subscribed_channels) == 0, not_subscribed_channels

    async def send_subscription_warning(self, chat_id: int, user_id: int, user_mention: str, missing_channel_ids: List[int], is_admin: bool = False):
        """
        Отправляет предупреждение о необходимости подписки на каналы.
        Принимает список ID недостающих каналов.
        Для обычных пользователей сразу отправляет в чат, для админов сначала пробует в ЛС.
        """
        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        from aiogram.utils.markdown import hlink
        
        # Получаем информацию о чате и пользователе для логов
        chat_info = await get_cached_chat_info(self.bot, chat_id)
        chat_title = chat_info.title if chat_info else f"Чат {chat_id}"
        
        user_info = None
        user_name = None
        try:
            user_info = await self.bot.get_chat(user_id)
            user_name = user_info.full_name
        except:
            user_name = f"Пользователь {user_id}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[])
        channel_name_for_msg = "наш канал"
        
        # Проверяем количество каналов
        multiple_channels = len(missing_channel_ids) > 1

        try:
            # Подготовим ссылки на все каналы
            channel_links = []
            subscribe_url = None
            
            for channel_id in missing_channel_ids:
                # Получаем информацию о канале
                channel_info = await get_cached_chat_info(self.bot, channel_id)
                
                if not channel_info:
                    logger.warning(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                                          chat_id=chat_id, chat_title=chat_title,
                                          extra_info=f"Не удалось получить информацию о канале {channel_id}"))
                    channel_links.append(f"канал {channel_id}")
                    continue
                
                channel_title = channel_info.title or f"Канал {channel_id}"
                
                # Пытаемся получить ссылку на канал
                channel_url = None
                if channel_info.username:
                    channel_url = f"https://t.me/{channel_info.username}"
                elif hasattr(channel_info, 'invite_link') and channel_info.invite_link:
                    channel_url = channel_info.invite_link
                
                # Создаем HTML-ссылку или просто название
                if channel_url:
                    channel_links.append(hlink(channel_title, channel_url))
                    # Запоминаем URL первого канала для кнопки "Подписаться"
                    if not subscribe_url:
                        subscribe_url = channel_url
                else:
                    channel_links.append(channel_title)
            
            # Если нет ни одной ссылки, используем предоставленную
            if not subscribe_url:
                subscribe_url = "https://t.me/+_kz8VaxvLCs1MWIy"
                logger.warning(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                                      chat_id=chat_id, chat_title=chat_title,
                                      extra_info=f"Не удалось получить ссылки на каналы, используем запасную"))
            
            # Формируем ссылки для текста сообщения
            if channel_links:
                if multiple_channels:
                    channels_text = ", ".join(channel_links)
                    channel_name_for_msg = f"каналы: {channels_text}"
                else:
                    channel_name_for_msg = channel_links[0]
            else:
                channel_name_for_msg = "наш канал"
                
            # Добавляем кнопку "Подписаться" с URL
            subscribe_button = InlineKeyboardButton(
                text="Подписаться", 
                url=subscribe_url
            )
            keyboard.inline_keyboard.append([subscribe_button])
            
            # Добавляем кнопку "Проверить подписку"
            check_subscription_button = InlineKeyboardButton(
                text="🔄 Проверить подписку", 
                callback_data=f"subcheck:{chat_id}"
            )
            keyboard.inline_keyboard.append([check_subscription_button])

        except Exception as e:
            logger.error(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                                chat_id=chat_id, chat_title=chat_title,
                                extra_info=f"Ошибка при обработке каналов: {e}"), exc_info=True)
            channel_name_for_msg = "наш канал" # Запасной вариант
        
        # Создаем ссылку "Заказать бот"
        order_bot_link_html = hlink("Заказать бот", "https://t.me/daoqub")

        # Формируем сообщение для чата
        message_text = (
            f"{user_mention}, чтобы писать сообщения в чате, подпишитесь на {channel_name_for_msg}\n\n"
            f"Без подписки сообщения удаляются!😇\n"
            f"{order_bot_link_html}"
        )

        # Если админ, отправляем ему список каналов в ЛС
        if is_admin:
            try:
                # Формируем список каналов с названиями и ссылками
                channel_list = []
                for ch_id in missing_channel_ids:
                    ch_info = await get_cached_chat_info(self.bot, ch_id)
                    if ch_info and ch_info.title:
                        # Пытаемся получить ссылку
                        ch_url = None
                        if ch_info.username:
                            ch_url = f"https://t.me/{ch_info.username}"
                        elif hasattr(ch_info, 'invite_link') and ch_info.invite_link:
                            ch_url = ch_info.invite_link
                            
                        if ch_url:
                            channel_list.append(f"• {hlink(ch_info.title, ch_url)}")
                        else:
                            channel_list.append(f"• {ch_info.title} (ID: {ch_id})")
                    else:
                        channel_list.append(f"• ID: {ch_id}")
                        
                admin_channels_text = "\n".join(channel_list) if channel_list else "(список пуст)"
                admin_message = f"ℹ️ Для продолжения общения в группе, вам необходимо подписаться на следующие каналы:\n\n{admin_channels_text}"
                await self.bot.send_message(
                    user_id, admin_message, reply_markup=keyboard, parse_mode="HTML"
                )
                logger.info(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                                  chat_id=chat_id, chat_title=chat_title,
                                  extra_info="Отправлено предупреждение админу в личные сообщения"))
                return
            except Exception as e:
                logger.error(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                                  chat_id=chat_id, chat_title=chat_title,
                                  extra_info=f"Не удалось отправить предупреждение в личку админу: {e}"))
        
        # Отправляем в чат
        sent_message = None
        try:
            sent_message = await self.bot.send_message(
                chat_id, message_text, reply_markup=keyboard,
                parse_mode="HTML", disable_web_page_preview=True
            )
            logger.info(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                              chat_id=chat_id, chat_title=chat_title,
                              extra_info="Отправлено предупреждение в чат"))
            if sent_message:
                 asyncio.create_task(self._delete_message_after_delay(chat_id, sent_message.message_id, 10))
        except Exception as e2:
            logger.error(format_sub_log("SUB_WARNING", user_id=user_id, user_name=user_name,
                              chat_id=chat_id, chat_title=chat_title,
                              extra_info=f"Не удалось отправить предупреждение в чат: {e2}"))

    async def _delete_message_after_delay(self, chat_id: int, message_id: int, delay: int):
        """Удаляет сообщение с указанной задержкой."""
        await asyncio.sleep(delay)
        try:
            await self.bot.delete_message(chat_id, message_id)
            
            # Получаем название чата для логов
            chat_info = await get_cached_chat_info(self.bot, chat_id)
            chat_title = chat_info.title if chat_info else f"Чат {chat_id}"
            
            logger.debug(format_sub_log("SUB_DEL", chat_id=chat_id, chat_title=chat_title,
                               extra_info=f"Сообщение {message_id} удалено после задержки"))
        except TelegramAPIError as e:
            # Получаем название чата для логов
            chat_info = await get_cached_chat_info(self.bot, chat_id)
            chat_title = chat_info.title if chat_info else f"Чат {chat_id}"
            
            logger.warning(format_sub_log("SUB_DEL", chat_id=chat_id, chat_title=chat_title,
                                 extra_info=f"Не удалось удалить сообщение {message_id}: {e}"))

    async def handle_subscription_check_callback(self, callback_query: CallbackQuery):
        """
        Обрабатывает нажатие на кнопку проверки подписки.
        """
        user_id = callback_query.from_user.id
        data = callback_query.data
        # Получаем chat_id из callback_data
        chat_id = int(data.split(':')[1]) if len(data.split(':')) > 1 else None
        
        # Если chat_id не указан или плохой формат, используем ID чата из callback_query
        if not chat_id:
            chat_id = callback_query.message.chat.id
            logger.warning(format_sub_log("SUB_CHECK", user_id=user_id, 
                              chat_id=chat_id, extra_info=f"Не удалось получить chat_id из callback_data"))
            
        # Получаем информацию о чате и пользователе для логов
        chat_info = await get_cached_chat_info(self.bot, chat_id)
        chat_title = chat_info.title if chat_info else f"Чат {chat_id}"
        
        user_info = callback_query.from_user
        user_name = user_info.username or f"{user_info.first_name} {user_info.last_name or ''}"
        user_mention = get_user_link_for_md(user_id, user_name)
        
        # Получаем информацию о боте для более персонализированного сообщения
        try:
            me = await self.bot.get_me()
            bot_name = me.username
        except Exception as e:
            logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                               chat_id=chat_id, chat_title=chat_title,
                               extra_info=f"Не удалось получить информацию о боте: {e}"))
            bot_name = "бота"
            
        # Получаем настройки подписки для чата
        settings = await self.db.get_chat_settings(chat_id)
        if not settings:
            # Если настройки не найдены, сообщаем об этом и выходим
            logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                               chat_id=chat_id, chat_title=chat_title,
                               extra_info="Настройки подписки не найдены"))
            try:
                await self.bot.answer_callback_query(
                    callback_query.id,
                    "⚠️ Настройки подписки не найдены. Обратитесь к администратору.",
                    show_alert=True
                )
            except Exception as e:
                logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                   extra_info=f"Ошибка при ответе на callback_query: {e}"))
            return

        # Показываем пользователю, что проверка началась
        try:
            await self.bot.answer_callback_query(
                callback_query.id,
                "🔍 Проверка подписки... Пожалуйста, подождите.",
                show_alert=False
            )
            logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                chat_id=chat_id, chat_title=chat_title,
                                extra_info="Отправлен ответ о начале проверки"))
        except Exception as e:
            logger.warning(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                 extra_info=f"Не удалось отправить ответ о начале проверки: {e}"))

        # ОЧИЩАЕМ КЭШ ПОДПИСОК для этого пользователя перед проверкой
        # Получаем каналы, привязанные к чату
        linked_channels = await self.db.get_linked_channels_for_chat(chat_id)
        if linked_channels:
            for channel_id in linked_channels:
                # Удаляем запись из кэша, чтобы проверка была свежей
                if (user_id, channel_id) in _subscription_cache:
                    del _subscription_cache[(user_id, channel_id)]
                    logger.info(format_sub_log("SUB_CACHE_CLEAR", user_id=user_id, user_name=user_name,
                                              extra_info=f"🧹 Очищен кэш подписки для канала {channel_id}"))

        # Проверяем подписку
        is_subscribed, not_subscribed_channels = await self.check_subscription(user_id, chat_id)
        
        # Получаем названия непоскрибленных каналов для лога и сообщения
        channel_names = []
        for ch_id in not_subscribed_channels:
            ch_info = await get_cached_chat_info(self.bot, ch_id)
            if ch_info and ch_info.title:
                channel_names.append(f"{ch_info.title} (ID: {ch_id})")
            else:
                channel_names.append(f"Канал {ch_id}")
        
        channels_str = ", ".join(channel_names) if channel_names else "нет"
        logger.info(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                           chat_id=chat_id, chat_title=chat_title,
                           extra_info=f"Результат проверки: подписан={is_subscribed}, отсутствуют подписки: {channels_str}"))
        
        # Формируем и отправляем ответ пользователю
        if is_subscribed:
            # Если подписан на все каналы
            success_message = f"✅ Вы подписаны на все необходимые каналы! Теперь вы можете отправлять сообщения в чат {chat_title}."
            try:
                await self.bot.answer_callback_query(
                    callback_query.id,
                    "✅ Проверка успешно пройдена! Вы подписаны на все каналы.",
                    show_alert=True
                )
                logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                   chat_id=chat_id, chat_title=chat_title,
                                   extra_info="Отправлен успешный ответ о подписке"))

                # Дополнительно можно отправить сообщение в чат или изменить текущее
                # await self.bot.send_message(chat_id, success_message)

            except Exception as e:
                logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                   extra_info=f"Ошибка при отправке успешного ответа: {e}"))
        else:
            # Если не подписан на какие-то каналы
            fail_message = f"❌ Вы не подписаны на следующие каналы:\n" + "\n".join([f"• {name}" for name in channel_names]) if channel_names else "неизвестно"
            try:
                await self.bot.answer_callback_query(
                    callback_query.id,
                    "❌ Проверка не пройдена. Пожалуйста, подпишитесь на все необходимые каналы.",
                    show_alert=True
                )
                logger.debug(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                   chat_id=chat_id, chat_title=chat_title,
                                   extra_info="Отправлен ответ о недостающих подписках"))

                # Отправляем предупреждение с кнопкой для подписки
                is_admin = False  # По умолчанию считаем пользователя не админом
                try:
                    member = await self.bot.get_chat_member(chat_id, user_id)
                    is_admin = member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]
                except Exception as e:
                    logger.warning(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                         chat_id=chat_id, chat_title=chat_title,
                                         extra_info=f"Не удалось проверить статус админа: {e}"))
                
                # Отправляем предупреждение с информацией о недостающих подписках
                await self.send_subscription_warning(
                    chat_id, user_id, user_mention, not_subscribed_channels, is_admin=is_admin
                )
            except Exception as e:
                logger.error(format_sub_log("SUB_CHECK", user_id=user_id, user_name=user_name,
                                   extra_info=f"Ошибка при отправке предупреждения: {e}"))

        # Обновляем БД, если необходимо (например, запись о проверке подписки) 
        try:
            # Обновляем статус подписки пользователя в БД
            current_time = int(time.time())
            await self.db.update_user_subscription_status(
                chat_id=chat_id, 
                user_id=user_id, 
                is_subscribed=is_subscribed, 
                timestamp=current_time
            )
            logger.info(f"[SUB_CHECK_CALLBACK] Обновлен статус подписки пользователя {user_id} в БД: {is_subscribed}")
            
            # Обновляем время последней проверки
            await self.db.update_last_subscription_check(
                chat_id=chat_id,
                user_id=user_id,
                timestamp=current_time
            )
        except Exception as e:
            logger.error(f"[SUB_CHECK_CALLBACK] Ошибка при обновлении статуса в БД: {e}", exc_info=True) 