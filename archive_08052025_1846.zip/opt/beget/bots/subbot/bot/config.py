from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr

# Имя файла базы данных (можно вынести в .env при желании)
DB_NAME = 'bot_data.db'
# Имя бота (для использования в текстах, можно брать из .env)
# Если не задано в .env, можно использовать значение по умолчанию
# BOT_USERNAME = 'YourBotName'

class Settings(BaseSettings):
    # Загружаем переменные из .env файла
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore') # extra='ignore' чтобы не ругался на DB_NAME

    # Токен бота обязателен
    bot_token: SecretStr
    # Имя пользователя бота (опционально, берется из .env)
    bot_username: str | None = None 

    # Можно добавить другие глобальные настройки по мере необходимости
    # super_admin_id: int | None = None

# Создаем экземпляр настроек, который будем импортировать в другие модули
settings = Settings()

# Определяем BOT_USERNAME для использования в коде
# Приоритет: из .env, если нет - используем значение по умолчанию (можно задать выше)
BOT_USERNAME = settings.bot_username or 'YourCheckSubBot' # Замените 'YourCheckSubBot' на имя по умолчанию, если нужно 