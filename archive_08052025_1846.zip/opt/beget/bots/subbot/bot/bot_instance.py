import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties # Для ParseMode
from aiogram.fsm.storage.memory import MemoryStorage # Импорт хранилища

# Обновленный импорт DatabaseManager
from bot.db.database import DatabaseManager
from bot.config import settings
# Возвращаем АБСОЛЮТНЫЕ импорты middleware:
from bot.middlewares.db_middleware import DbSessionMiddleware 
from bot.middlewares.bot_middleware import BotMiddleware 

logger = logging.getLogger(__name__)

# Инициализация менеджера БД
db_manager = DatabaseManager()

# Инициализация хранилища состояний
storage = MemoryStorage()

# Инициализация бота и диспетчера
# Убираем db_manager из конструктора Dispatcher
dp = Dispatcher(storage=storage) 
bot = Bot(
    token=settings.bot_token.get_secret_value(),
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)

# Регистрируем middleware для передачи db_manager в хендлеры
dp.update.middleware(DbSessionMiddleware(db_manager))

# Регистрируем middleware для передачи bot в хендлеры
dp.update.middleware(BotMiddleware(bot))

logger.info("Bot, Dispatcher, DB Manager и Middlewares инициализированы.") 