"""
Пакет для хранения данных (CallbackData, States и т.д.)
""" 