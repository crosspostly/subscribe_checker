from aiogram.fsm.state import State, StatesGroup

# Состояние для добавления канала (старый вариант, можно удалить или оставить)
# class AddChannel(StatesGroup):
#     waiting_for_input = State()

# Новые состояния для интерактивного добавления/управления каналами
class ManageChannels(StatesGroup):
    # Сценарий 1: Через команду /setup в чате
    waiting_for_channel_select = State() # Ожидание выбора канала через кнопку request_chat после команды

    # Сценарий 2: Через добавление бота админом
    waiting_for_channel_select_admin = State() # Ожидание выбора канала через кнопку request_chat после добавления админом

    managing_list = State()              # Состояние управления списком (отображены кнопки Добавить/Удалить/Готово)
    waiting_for_channel_remove = State() # Ожидание выбора канала для удаления (отображена клавиатура с каналами)
    adding_channel = State()             # Состояние добавления нового канала
    
    # Состояния для передачи прав
    waiting_for_transfer_target = State() # Ожидание ввода ID пользователя для передачи прав
    waiting_for_transfer_confirm = State() # Ожидание подтверждения передачи прав

# Другие группы состояний можно добавлять сюда же
# class SomeOtherFeature(StatesGroup):
#     step1 = State()
#     step2 = State() 