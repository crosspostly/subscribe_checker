import asyncio
import logging
import os
import sys # Добавляем sys
import time # Добавляем time для работы с временем

# Импортируем нужные объекты
from bot.bot_instance import bot, dp, db_manager
# Импортируем роутеры
# Старый импорт: from bot.handlers import admin, user, callbacks
from bot.handlers import admin, callbacks, group_messages, group_admin, fsm_private, private_messages
# Импортируем исключения
from aiogram.exceptions import TelegramAPIError, TelegramConflictError

# --- Настройка логирования с colorlog --- (Новый блок)

LOGS_DIR = "logs"
LOG_LEVEL = logging.INFO # Уровень логирования (INFO, DEBUG, WARNING, ERROR, CRITICAL)
LOG_FORMAT_CONSOLE = '%(log_color)s%(asctime)s | %(levelname)-8s | %(name)-25s | %(funcName)-20s | %(lineno)-4d | %(message)s%(reset)s'
LOG_FORMAT_FILE = '%(asctime)s | %(levelname)-8s | %(name)-25s | %(funcName)-20s | %(lineno)-4d | %(message)s'

# Создаем папку для логов
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)

# Базовая конфигурация logging
logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT_FILE)

# Настройка colorlog для консоли
try:
    import colorlog
    # Настройка обработчика для консоли с цветами
    console_handler = colorlog.StreamHandler(sys.stdout)
    console_handler.setFormatter(colorlog.ColoredFormatter(LOG_FORMAT_CONSOLE, datefmt='%Y-%m-%d %H:%M:%S'))

    # Настройка обработчика для файла (без цветов)
    file_handler = logging.FileHandler(os.path.join(LOGS_DIR, "bot.log"), encoding='utf-8')
    file_handler.setFormatter(logging.Formatter(LOG_FORMAT_FILE, datefmt='%Y-%m-%d %H:%M:%S'))

    # Получаем корневой логгер и добавляем обработчики
    root_logger = logging.getLogger()
    root_logger.handlers = [] # Удаляем стандартные обработчики basicConfig
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    root_logger.setLevel(LOG_LEVEL)

    logging.getLogger('aiogram').setLevel(logging.WARNING) # Уменьшаем шум от aiogram
    logging.getLogger('aiosqlite').setLevel(logging.WARNING) # Уменьшаем шум от aiosqlite
    logging.getLogger('asyncio').setLevel(logging.WARNING)

    logger = logging.getLogger(__name__) # Получаем логгер для этого модуля
    logger.info("Colorlog успешно настроен.")

except ImportError:
    print("Библиотека colorlog не найдена. Установите ее: pip install colorlog")
    print("Логирование будет работать без цветов в консоли.")
    # Используем стандартную конфигурацию без цветов
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT_FILE,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(os.path.join(LOGS_DIR, "bot.log"), encoding='utf-8')
        ],
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    logging.getLogger('aiogram').setLevel(logging.WARNING)
    logging.getLogger('aiosqlite').setLevel(logging.WARNING)
    logging.getLogger('asyncio').setLevel(logging.WARNING)
    logger = logging.getLogger(__name__)
    logger.warning("Colorlog не найден, логирование в консоли без цветов.")

# ---------------------------------------

async def main():
    logger.info("Запуск бота...") # Логгер уже настроен

    # Инициализация базы данных
    try:
        await db_manager.init_db()
        logger.info("База данных успешно инициализирована.")
        # ВЫЗЫВАЕМ МИГРАЦИИ ПОСЛЕ ИНИЦИАЛИЗАЦИИ
        await db_manager.run_migrations()
        logger.info("Миграции базы данных успешно выполнены.")
    except Exception as e:
        logger.critical(f"Критическая ошибка при инициализации или миграции БД: {e}", exc_info=True)
        return # Завершаем работу, если БД не инициализирована или миграция не удалась

    # Подключение роутеров
    # bot и db_manager должны быть доступны через middleware (DbSessionMiddleware и BotMiddleware)
    # Поэтому нет необходимости передавать их явно при подключении роутеров.

    # Роутеры для ЛС
    dp.include_router(private_messages.pm_router)
    logger.debug("Роутер для ЛС (pm_router) подключен.")
    dp.include_router(fsm_private.fsm_private_router)
    logger.debug("Роутер FSM в ЛС подключен.")
    
    # Роутеры для групп
    dp.include_router(group_admin.group_admin_router)
    logger.debug("Роутер администрирования групп подключен.")
    dp.include_router(admin.admin_router)
    logger.debug("Админский роутер подключен.")
    dp.include_router(callbacks.callback_router)
    logger.debug("Роутер коллбеков подключен.")
    dp.include_router(group_messages.group_msg_router)
    logger.debug("Роутер сообщений групп подключен.")

    # Удаление вебхука перед запуском (на всякий случай)
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        logger.info("Вебхук удален, ожидающие обновления сброшены.")
    except TelegramAPIError as e:
        logger.warning(f"Не удалось удалить вебхук: {e}")

    # Настройка команд меню бота
    await setup_bot_commands()
    logger.info("Команды меню бота настроены")

    # Запуск фоновых задач
    asyncio.create_task(clean_old_bot_messages())
    logger.info("Запущена фоновая задача очистки старых сообщений бота")
    
    # Запуск поллинга
    logger.info("Запуск polling...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types()) # Передаем типы обновлений
    except TelegramConflictError:
        logger.critical("ОШИБКА: Обнаружен другой запущенный экземпляр бота! Завершение работы.")
        # Можно добавить команду для убийства процессов здесь, но лучше делать это вручную
    except Exception as e:
        logger.critical(f"Критическая ошибка в процессе polling: {e}", exc_info=True)
    finally:
        logger.info("Завершение работы бота...")
        try:
            await bot.session.close()
            logger.info("Сессия бота закрыта.")
        except Exception as e:
            logger.error(f"Ошибка при закрытии сессии бота: {e}")
        await db_manager.close_db()
        logger.info("Соединение с БД закрыто.")
        logger.info("Бот остановлен.")

async def setup_bot_commands():
    """Устанавливает команды меню бота"""
    from aiogram.types import BotCommand, BotCommandScopeDefault
    
    commands = [
        BotCommand(command="start", description="Начать работу с ботом"),
        BotCommand(command="getcode", description="Получить код настройки для группы"),
        BotCommand(command="mychats", description="Показать настроенные чаты"),
        BotCommand(command="help", description="Показать справку по командам")
    ]
    
    try:
        # Устанавливаем команды для всех пользователей
        await bot.set_my_commands(commands, scope=BotCommandScopeDefault())
        logger.info("Команды меню бота успешно настроены")
    except TelegramAPIError as e:
        logger.error(f"Ошибка при настройке команд меню бота: {e}")

async def clean_old_bot_messages():
    """Периодически удаляет старые сообщения бота из чатов."""
    logger.info("Запущена задача очистки старых сообщений бота")
    while True:
        try:
            # Получаем информацию о боте
            bot_info = await bot.get_me()
            bot_id = bot_info.id
            
            # Получаем список чатов, где работает бот
            chats = await db_manager._execute("SELECT chat_id FROM chats", fetchall=True)
            
            current_time = int(time.time())
            # Для каждого чата проверяем и удаляем старые сообщения
            for chat_row in chats:
                chat_id = chat_row['chat_id']
                try:
                    # Проверяем, есть ли у бота права админа в чате
                    bot_member = await bot.get_chat_member(chat_id, bot_id)
                    if not bot_member or bot_member.status not in ["administrator", "creator"]:
                        logger.debug(f"Бот не имеет прав админа в чате {chat_id}, пропускаем очистку")
                        continue
                        
                    # TODO: Здесь можно добавить логику удаления старых сообщений, 
                    # но для этого нужен список сообщений бота в чате.
                    # Telegram API не позволяет получить историю сообщений через бота напрямую.
                    # Возможно, стоит сохранять ID отправленных ботом сообщений в БД
                    # и затем удалять их по расписанию.
                    
                    logger.info(f"Проверка старых сообщений в чате {chat_id}")
                    
                except Exception as e:
                    logger.warning(f"Ошибка при очистке сообщений в чате {chat_id}: {e}")
            
            logger.debug("Цикл очистки сообщений завершен")
        except Exception as e:
            logger.error(f"Ошибка в задаче очистки сообщений: {e}")
        
        # Ждем 6 часов перед следующей проверкой
        await asyncio.sleep(6 * 60 * 60)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Бот остановлен вручную (KeyboardInterrupt/SystemExit).") 