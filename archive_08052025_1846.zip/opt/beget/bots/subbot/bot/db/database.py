"""
Управление базой данных SQLite с использованием aiosqlite.
"""
import logging
import time
import json
from typing import Optional, List, Tuple, Dict, Any, Union
import aiosqlite
import os
import sqlite3
from aiogram.enums import ChatMemberStatus
from collections import defaultdict

# Импорты для относительных путей при запуске через `python -m bot`
from bot.config import DB_NAME

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Асинхронный менеджер базы данных SQLite."""
    def __init__(self, db_path: str = DB_NAME):
        self.db_path = db_path
        # Убрали self._connection, будем использовать контекстный менеджер в _execute

    async def run_migrations(self):
        """Применяет необходимые миграции схемы БД (вызывается после init_db)."""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            try:
                # Проверяем, существует ли таблица 'chats'
                cursor_check = await db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='chats'")
                table_exists = await cursor_check.fetchone()

                if not table_exists:
                    logger.info("Таблица 'chats' еще не существует. Миграции для 'chats' будут пропущены.")
                    # Можно добавить сюда логику для других таблиц, если нужно
                    # Например, проверить существование других таблиц перед их миграцией
                    
                    # Если основной таблицы 'chats' нет, возможно, нет смысла продолжать миграции для связанных таблиц
                    # или нужно добавить проверки и для них. Пока просто выходим.
                    # В будущем можно будет добавить проверки для других таблиц здесь.
                    
                    # Проверяем таблицу users_status_in_chats для _check_and_add_missing_columns
                    cursor_check_users = await db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users_status_in_chats'")
                    users_table_exists = await cursor_check_users.fetchone()
                    if not users_table_exists:
                         logger.info("Таблица 'users_status_in_chats' еще не существует. Проверка колонки 'is_subscribed' будет пропущена.")
                         return # Выходим, если нет обеих таблиц

                    # Проверяем и добавляем колонку is_subscribed ТОЛЬКО если users_status_in_chats существует
                    await self._check_and_add_missing_columns_internal(db) 
                    return # Выходим после проверки/добавления колонки, т.к. 'chats' нет
                    
                # Получаем информацию о колонках ТОЛЬКО если таблица 'chats' существует
                cursor_info = await db.execute("PRAGMA table_info(chats)")
                columns = {row['name'] for row in await cursor_info.fetchall()} # Используем set для быстрой проверки

                migration_applied = False

                # Миграция 1: Добавление added_by_user_id в chats
                if 'added_by_user_id' not in columns:
                    logger.info("Миграция: Добавление колонки 'added_by_user_id' в таблицу 'chats'...")
                    await db.execute("ALTER TABLE chats ADD COLUMN added_by_user_id INTEGER")
                    migration_applied = True
                    logger.info("Миграция: Колонка 'added_by_user_id' добавлена (ожидает commit).")
                
                # Миграция 2: Добавление configured_by_user_id в chats
                if 'configured_by_user_id' not in columns:
                    logger.info("Миграция: Добавление колонки 'configured_by_user_id' в таблицу 'chats'...")
                    await db.execute("ALTER TABLE chats ADD COLUMN configured_by_user_id INTEGER")
                    migration_applied = True
                    logger.info("Миграция: Колонка 'configured_by_user_id' добавлена (ожидает commit).")
                
                # Миграция 3: Добавление setup_complete в chats
                if 'setup_complete' not in columns:
                    logger.info("Миграция: Добавление колонки 'setup_complete' в таблицу 'chats'...")
                    await db.execute("ALTER TABLE chats ADD COLUMN setup_complete INTEGER DEFAULT 0")
                    migration_applied = True
                    logger.info("Миграция: Колонка 'setup_complete' добавлена (ожидает commit).")

                # --- Добавляйте сюда другие миграции по мере необходимости ---
                
                # Проверяем и добавляем колонку is_subscribed в users_status_in_chats (если таблица существует)
                await self._check_and_add_missing_columns_internal(db)
                
                # Коммитим все изменения схемы одним разом, если они были
                if migration_applied:
                    await db.commit()
                    logger.info("Миграции схемы БД успешно применены и закоммичены.")

            except aiosqlite.Error as e:
                logger.error(f"Ошибка при выполнении миграции БД: {e}", exc_info=True)
                # Важно! Если миграция не удалась, возможно, стоит прервать работу.
                raise e # Пробрасываем ошибку выше

    async def _execute(
        self, 
        query: Optional[str], 
        params: tuple = (), 
        fetchone: bool = False, 
        fetchall: bool = False, 
        commit: bool = False,
        close: bool = False # Параметр close больше не нужен при использовании контекстного менеджера
    ) -> Optional[Union[aiosqlite.Row, List[aiosqlite.Row], None]]:
        """Вспомогательный метод для выполнения SQL-запросов."""
        # Используем try...except для обработки ошибок подключения/выполнения
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Включаем поддержку внешних ключей
                await db.execute("PRAGMA foreign_keys = ON")
                db.row_factory = aiosqlite.Row # Возвращать строки как объекты Row
                
                # Если query не None, выполняем его
                if query:
                    async with db.execute(query, params) as cursor:
                        if commit:
                            await db.commit()
                        if fetchone:
                            return await cursor.fetchone()
                        if fetchall:
                            return await cursor.fetchall()
                # Если query is None, это может быть использовано для других операций, 
                # например, для commit после нескольких запросов без commit=True
                elif commit:
                    await db.commit()
                    
                return None # Возвращаем None, если ничего не надо возвращать
        except aiosqlite.Error as e:
            logger.error(f"Ошибка SQLite при выполнении запроса: Query={query}, Params={params}, Error: {e}", exc_info=True)
            # В зависимости от критичности можно пробросить исключение дальше
            # raise e 
            return None # Или вернуть None/пустой список в случае ошибки

    async def init_db(self):
        """Инициализация таблиц базы данных (НОВАЯ СХЕМА)."""
        # Таблица пользователей (глобальная информация)
        await self._execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                language_code TEXT,
                is_premium INTEGER DEFAULT 0,
                first_seen_timestamp INTEGER NOT NULL,
                last_seen_timestamp INTEGER,
                referrer_id INTEGER, -- ID пользователя, который его пригласил
                FOREIGN KEY (referrer_id) REFERENCES users(user_id) ON DELETE SET NULL
            )
        """)
        # Таблица групповых чатов, где работает бот
        await self._execute("""
            CREATE TABLE IF NOT EXISTS chats (
                chat_id INTEGER PRIMARY KEY,
                chat_title TEXT,
                captcha_enabled INTEGER DEFAULT 1,
                subscription_check_enabled INTEGER DEFAULT 1,
                setup_complete INTEGER DEFAULT 0, -- Флаг завершения настройки
                added_timestamp INTEGER, 
                configured_by_user_id INTEGER, -- Кто последний раз успешно запускал /setup
                FOREIGN KEY (configured_by_user_id) REFERENCES users(user_id) ON DELETE SET NULL
            )
        """, commit=False) # Убираем commit здесь, он будет в конце init_db
        
        # Таблица связей "Чат -> Канал для подписки"
        await self._execute("""
            CREATE TABLE IF NOT EXISTS chat_channel_links (
                link_id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_chat_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                added_by_user_id INTEGER,
                added_timestamp INTEGER NOT NULL,
                FOREIGN KEY (group_chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE,
                FOREIGN KEY (added_by_user_id) REFERENCES users(user_id) ON DELETE SET NULL,
                -- FOREIGN KEY (channel_id) REFERENCES channels(channel_id) ON DELETE CASCADE, -- Если есть таблица channels
                UNIQUE (group_chat_id, channel_id) -- Нельзя добавить один канал в чат дважды
            )
        """)
        # Таблица статуса пользователя В ЧАТЕ (бывшая users)
        await self._execute("""
            CREATE TABLE IF NOT EXISTS users_status_in_chats (
                user_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                captcha_passed INTEGER DEFAULT 0,
                ban_until INTEGER DEFAULT 0,
                is_subscribed INTEGER DEFAULT 0,
                last_update_timestamp INTEGER,
                PRIMARY KEY (user_id, chat_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
            )
        """, commit=True) # Коммитим все изменения схемы в конце
        
        logger.info("База данных инициализирована (Новая схема).")
        
        # Убираем вызов _check_and_add_missing_columns отсюда, он теперь внутри _run_migrations
        # await self._check_and_add_missing_columns() # <- УДАЛИТЬ ИЛИ ЗАКОММЕНТИРОВАТЬ ЭТУ СТРОКУ

    async def _check_and_add_missing_columns(self):
        """Проверяет и добавляет отсутствующие колонки в таблицы (ВНЕШНИЙ МЕТОД).
        Этот метод теперь является оберткой для вызова через _execute, 
        а основная логика перенесена в _check_and_add_missing_columns_internal."""
        # Этот метод больше не должен напрямую использовать connect, 
        # т.к. проверка колонки теперь вызывается из _run_migrations, где соединение уже есть.
        # Оставим его пустым или для будущих проверок, не связанных с миграциями.
        # Можно просто удалить его содержимое или весь метод, если он больше нигде не используется.
        logger.debug("_check_and_add_missing_columns вызван, но логика перенесена в _run_migrations.")
        pass 
        # Если этот метод все же нужен для вызова ИЗВНЕ _execute/_run_migrations:
        # try:
        #     async with aiosqlite.connect(self.db_path) as db:
        #         await self._check_and_add_missing_columns_internal(db)
        # except Exception as e:
        #     logger.error(f"Ошибка при внешнем вызове проверки/добавлении колонок: {e}", exc_info=True)

    async def _check_and_add_missing_columns_internal(self, db: aiosqlite.Connection):
        """Проверяет и добавляет отсутствующие колонки (ВНУТРЕННИЙ МЕТОД). 
        Принимает существующее соединение."""
        try:
            # Проверяем наличие колонки is_subscribed в таблице users_status_in_chats
            # Убедимся что таблица users_status_in_chats существует перед PRAGMA
            cursor_check = await db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users_status_in_chats'")
            users_table_exists = await cursor_check.fetchone()
            
            if not users_table_exists:
                logger.info("Таблица 'users_status_in_chats' не найдена при проверке колонки 'is_subscribed'.")
                return # Нечего проверять

            query = "PRAGMA table_info(users_status_in_chats)"
            cursor = await db.execute(query)
            columns = await cursor.fetchall()
            
            # Ищем колонку is_subscribed
            is_subscribed_exists = any(col[1] == 'is_subscribed' for col in columns)
            
            if not is_subscribed_exists:
                logger.warning("Колонка is_subscribed отсутствует в таблице users_status_in_chats. Добавляю...")
                alter_query = "ALTER TABLE users_status_in_chats ADD COLUMN is_subscribed INTEGER DEFAULT 0"
                await db.execute(alter_query)
                await db.commit()
                logger.info("Колонка is_subscribed успешно добавлена в таблицу users_status_in_chats.")
                
        except Exception as e:
            logger.error(f"Ошибка при проверке/добавлении колонки is_subscribed: {e}", exc_info=True)

    async def close_db(self):
        """Закрывает соединение с базой данных (больше не требуется с context manager)."""
        # Метод больше не нужен, так как connect используется как контекстный менеджер
        logger.debug("close_db() вызван, но больше не выполняет действий.")
        pass 

    # --- Users ---
    
    async def add_user_if_not_exists(
        self, 
        user_id: int, 
        username: Optional[str], 
        first_name: Optional[str], 
        last_name: Optional[str] = None, 
        language_code: Optional[str] = None,
        is_premium: Optional[bool] = False,
        referrer_id: Optional[int] = None # Принимаем ID реферера при первом добавлении
    ) -> bool:
        """Добавляет пользователя, если его нет. Возвращает True, если пользователь был добавлен, False - если уже существовал."""
        current_time = int(time.time())
        existing_user = await self.get_user(user_id)
        
        if existing_user:
            # Обновляем last_seen и, возможно, другую информацию
            await self._execute(
                """UPDATE users SET last_seen_timestamp = ?, username = ?, first_name = ?, last_name = ?, language_code = ?, is_premium = ? 
                WHERE user_id = ?""",
                (current_time, username, first_name, last_name, language_code, int(is_premium or 0), user_id),
                commit=True
            )
            return False # Пользователь уже существовал
        else:
            # Добавляем нового пользователя
            await self._execute(
                """INSERT INTO users (user_id, username, first_name, last_name, language_code, is_premium, first_seen_timestamp, last_seen_timestamp, referrer_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (user_id, username, first_name, last_name, language_code, int(is_premium or 0), current_time, current_time, referrer_id),
                commit=True
            )
            logger.info(f"Добавлен новый пользователь: {user_id} ({username}), referrer: {referrer_id}")
            return True # Пользователь был добавлен
            
    async def get_user(self, user_id: int) -> Optional[aiosqlite.Row]:
        """Получение информации о пользователе."""
        return await self._execute("SELECT * FROM users WHERE user_id = ?", (user_id,), fetchone=True)
        
    async def record_referral(self, referred_id: int, referrer_id: int) -> bool:
        """Записывает реферера для пользователя, если он еще не установлен."""
        # Проверяем, что у пользователя еще нет реферера
        user = await self.get_user(referred_id)
        if user and user['referrer_id'] is None:
            await self._execute(
                "UPDATE users SET referrer_id = ? WHERE user_id = ?",
                (referrer_id, referred_id),
                commit=True
            )
            logger.info(f"Пользователю {referred_id} установлен реферер {referrer_id}")
            return True
        elif user and user['referrer_id'] is not None:
            logger.warning(f"Попытка установить реферера {referrer_id} для {referred_id}, у которого уже есть реферер {user['referrer_id']}")
            return False
        else:
            logger.error(f"Попытка установить реферера для несуществующего пользователя {referred_id}")
            return False
            
    async def get_referral_chain(self, user_id: int, max_levels: int = 4) -> List[int]:
        """Получает цепочку рефереров вверх до max_levels."""
        chain = []
        current_id = user_id
        for _ in range(max_levels):
            user = await self.get_user(current_id)
            if user and user['referrer_id']:
                referrer_id = user['referrer_id']
                chain.append(referrer_id)
                current_id = referrer_id
            else:
                break # Достигли верха цепочки или пользователя без реферера
        return chain

    # --- Chat Settings ---

    async def add_chat_if_not_exists(
        self, 
        chat_id: int, 
        chat_title: Optional[str], 
        added_by_user_id: Optional[int] = None
    ):
        """Добавляет чат, если его нет. Устанавливает setup_complete=0."""
        current_time = int(time.time())
        # Используем INSERT OR IGNORE для простоты
        await self._execute(
            """INSERT OR IGNORE INTO chats (chat_id, chat_title, added_timestamp, added_by_user_id, setup_complete) 
               VALUES (?, ?, ?, ?, 0)""",
            (chat_id, chat_title, current_time, added_by_user_id),
            commit=True # Коммитим добавление чата
        )
        # Обновляем название, если чат уже был
        await self._execute(
            "UPDATE chats SET chat_title = ? WHERE chat_id = ? AND chat_title IS NOT ?",
            (chat_title, chat_id, chat_title),
            commit=True
        )
        logger.info(f"[DB] Чат {chat_id} ('{chat_title}') добавлен/проверен в БД (автоматически при становлении админом или первом обращении).")

    async def get_chat_settings(self, chat_id: int) -> Optional[Dict[str, Any]]:
        """Получение настроек чата."""
        # Убедимся, что чат есть в базе (если его добавили вручную или что-то пошло не так)
        await self.add_chat_if_not_exists(chat_id, None)
        
        row = await self._execute("SELECT * FROM chats WHERE chat_id = ?", (chat_id,), fetchone=True)
        if row:
            result = dict(row)
            # Установка значений по умолчанию, если NULL (оставляем как есть)
            if 'subscription_check_enabled' not in result or result['subscription_check_enabled'] is None:
                result['subscription_check_enabled'] = 1
            if 'captcha_enabled' not in result or result['captcha_enabled'] is None:
                result['captcha_enabled'] = 1
            if 'setup_complete' not in result or result['setup_complete'] is None:
                 result['setup_complete'] = 0 # Добавляем проверку для setup_complete
            return result
        return None

    async def toggle_setting(self, chat_id: int, setting_name: str) -> Optional[bool]:
        """Переключает настройку (captcha_enabled или subscription_check_enabled)."""
        if setting_name not in ['captcha_enabled', 'subscription_check_enabled']:
            logger.error(f"Попытка переключить неизвестную настройку: {setting_name}")
            return None

        settings = await self.get_chat_settings(chat_id)
        if not settings: return None

        current_value = settings[setting_name]
        new_value = 1 - (current_value or 0) # Переключаем 0 -> 1, 1 -> 0, None -> 1
        await self._execute(
            f"UPDATE chats SET {setting_name} = ? WHERE chat_id = ?",
            (new_value, chat_id),
            commit=True
        )
        logger.info(f"Настройка '{setting_name}' для чата {chat_id} переключена на {new_value}")
        return bool(new_value)

    async def update_chat_settings(self, chat_id: int, settings: Dict[str, Any]) -> bool:
        """Обновляет настройки чата в базе данных."""
        try:
            # Получаем текущие настройки, чтобы не затереть неуказанные
            current_settings_db = await self.get_chat_settings(chat_id)
            if not current_settings_db:
                logger.error(f"Не удалось обновить настройки: чат {chat_id} не найден")
                return False

            # Собираем значения для обновления
            # Используем значения из settings, если они есть, иначе оставляем текущие из БД
            captcha_enabled = int(settings.get('captcha_enabled', current_settings_db.get('captcha_enabled', 1)))
            sub_check_enabled = int(settings.get('subscription_check_enabled', current_settings_db.get('subscription_check_enabled', 1)))
            # configured_by обновляется только если передан в settings
            configured_by = settings.get('configured_by_user_id', current_settings_db.get('configured_by_user_id'))
            # setup_complete обновляется только если передан в settings (хотя обычно его ставит mark_setup_complete)
            setup_complete = int(settings.get('setup_complete', current_settings_db.get('setup_complete', 0)))

            # Обновляем запись в базе
            await self._execute(
                """UPDATE chats 
                SET captcha_enabled = ?, 
                    subscription_check_enabled = ?,
                    configured_by_user_id = ?,
                    setup_complete = ?
                WHERE chat_id = ?""",
                (
                    captcha_enabled,
                    sub_check_enabled,
                    configured_by,
                    setup_complete,
                    chat_id
                ),
                commit=True
            )
            logger.info(f"Настройки чата {chat_id} обновлены.") # Убрал вывод самих настроек
            return True

        except Exception as e:
            logger.error(f"Ошибка при обновлении настроек чата {chat_id}: {e}", exc_info=True) # Добавил exc_info
            return False

    async def mark_setup_complete(self, chat_id: int, user_id: int):
        """Отмечает чат как настроенный и записывает, кто настроил."""
        current_time = int(time.time())
        await self._execute(
            """UPDATE chats 
               SET setup_complete = 1, configured_by_user_id = ?, added_timestamp = ?
               WHERE chat_id = ?""",
            (user_id, current_time, chat_id),
            commit=True
        )
        logger.info(f"[DB] Чат {chat_id} помечен как настроенный пользователем {user_id}.")

    # --- Chat Channel Links ---

    async def add_linked_channel(self, group_chat_id: int, channel_id: int, added_by_user_id: Optional[int]) -> bool:
        """Добавляет связь канала с чатом. Возвращает True если добавлено, False если уже было."""
        current_time = int(time.time())
        try:
            # Проверяем, есть ли уже связанные каналы с этим чатом
            existing_channels = await self.get_linked_channels_for_chat(group_chat_id)
            is_first_channel = len(existing_channels) == 0
            
            # Добавляем канал
            await self._execute(
                """INSERT INTO chat_channel_links (group_chat_id, channel_id, added_by_user_id, added_timestamp) 
                VALUES (?, ?, ?, ?)""",
                (group_chat_id, channel_id, added_by_user_id, current_time),
                commit=True
            )
            
            # Если это первый канал, включаем проверку подписки
            if is_first_channel:
                await self._execute(
                    """UPDATE chats SET subscription_check_enabled = 1 WHERE chat_id = ? AND subscription_check_enabled = 0""",
                    (group_chat_id,),
                    commit=True
                )
                logger.info(f"Автоматически включена проверка подписки для чата {group_chat_id} после добавления первого канала")
                
            logger.info(f"Канал {channel_id} добавлен для чата {group_chat_id} пользователем {added_by_user_id}")
            return True
        except aiosqlite.IntegrityError: # Сработает из-за UNIQUE constraint
            logger.warning(f"Попытка повторно добавить канал {channel_id} в чат {group_chat_id}")
            return False
            
    async def remove_linked_channel(self, group_chat_id: int, channel_id: int) -> bool:
        """Удаляет связь канала с чатом. Возвращает True если удалено, False если не найдено."""
        result = await self._execute(
            "DELETE FROM chat_channel_links WHERE group_chat_id = ? AND channel_id = ?",
            (group_chat_id, channel_id),
            commit=True
        )
        # Проверяем количество удаленных строк (нужно настроить _execute для возврата rowcount?)
        # Пока просто логируем
        # Простой способ проверить - был ли такой канал перед удалением
        # count = await self._execute("SELECT COUNT(*) FROM chat_channel_links WHERE group_chat_id = ? AND channel_id = ?", (group_chat_id, channel_id), fetchone=True)
        # if count[0] == 0: # Если после удаления 0, значит удалили
        
        # Более простой вариант: просто логируем попытку
        logger.info(f"Попытка удалить канал {channel_id} из чата {group_chat_id}")
        # Для большей точности можно было бы сначала проверить наличие, потом удалять
        # или анализировать результат cursor.rowcount, если бы _execute его возвращал.
        # Пока будем считать, что если ошибки не было, то ок.
        return True 

    async def get_linked_channels_for_chat(self, group_chat_id: int) -> List[int]:
        """Возвращает список ID каналов, привязанных к чату."""
        rows = await self._execute(
            "SELECT channel_id FROM chat_channel_links WHERE group_chat_id = ?",
            (group_chat_id,),
            fetchall=True
        )
        return [row['channel_id'] for row in rows] if rows else []

    async def get_chats_configured_by_user(self, user_id: int) -> List[Dict[str, Any]]:
        """Возвращает список чатов и их каналов, настроенных пользователем."""
        # Получаем чаты, где пользователь добавлял каналы
        rows = await self._execute(
            """
            SELECT DISTINCT
                c.chat_id,
                c.chat_title
            FROM chats c
            JOIN chat_channel_links l ON c.chat_id = l.group_chat_id
            WHERE l.added_by_user_id = ?
            ORDER BY c.chat_title
            """,
            (user_id,),
            fetchall=True
        )
        
        if not rows:
            return []

        result = []
        for chat_row in rows:
            chat_info = {"chat_id": chat_row['chat_id'], "chat_title": chat_row['chat_title']}
            linked_channels = await self.get_linked_channels_for_chat(chat_row['chat_id'])
            # Опционально: получить названия каналов
            chat_info['channels'] = linked_channels # Пока только ID
            result.append(chat_info)
            
        return result

    # --- User Status In Chats ---

    async def get_user_status_in_chat(self, user_id: int, chat_id: int) -> Optional[aiosqlite.Row]:
        """Получение статуса пользователя В КОНКРЕТНОМ чате."""
        # Добавим пользователя глобально, если его нет
        # await self.add_user_if_not_exists(user_id, None, None) # Это нужно делать в хендлере
        # Добавим чат глобально, если его нет
        # await self.add_or_update_chat(chat_id, None) # Это нужно делать в хендлере
        
        return await self._execute(
            "SELECT * FROM users_status_in_chats WHERE user_id = ? AND chat_id = ?",
            (user_id, chat_id),
            fetchone=True
        )

    async def update_user_captcha_status(self, user_id: int, chat_id: int, passed: bool):
        """Обновляет статус прохождения капчи в конкретном чате."""
        # Сначала убедимся, что пользователь и чат существуют
        await self.add_user_if_not_exists(user_id, None, None, None)
        await self.add_chat_if_not_exists(chat_id, None)
        
        current_time = int(time.time())
        await self._execute(
            """INSERT INTO users_status_in_chats (user_id, chat_id, captcha_passed, last_update_timestamp) VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id, chat_id) DO UPDATE SET captcha_passed=excluded.captcha_passed, last_update_timestamp=excluded.last_update_timestamp""",
            (user_id, chat_id, int(passed), current_time),
            commit=True
        )

    async def update_user_ban_status(self, user_id: int, chat_id: int, ban_until: int):
        """Обновляет время бана пользователя в конкретном чате."""
        # Сначала убедимся, что пользователь и чат существуют
        await self.add_user_if_not_exists(user_id, None, None, None)
        await self.add_chat_if_not_exists(chat_id, None)
        
        current_time = int(time.time())
        await self._execute(
            """INSERT INTO users_status_in_chats (user_id, chat_id, ban_until, last_update_timestamp) VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, chat_id) DO UPDATE SET ban_until=excluded.ban_until, last_update_timestamp=excluded.last_update_timestamp""",
            (user_id, chat_id, ban_until, current_time),
            commit=True
        )

    # --- Referrals (Старые методы, возможно, не нужны или требуют адаптации) ---
    # async def add_referral(self, chat_id: int, referrer_id: int, referred_id: int): ...
    # async def get_referrals_count(self, chat_id: int, referrer_id: int) -> int: ...
    # async def get_user_referrer(self, chat_id: int, referred_id: int) -> Optional[int]: ... 

    async def get_active_chats_with_subscription_check(self) -> List[int]:
        """
        Получает список ID всех активных чатов с включенной проверкой подписки.
        Возвращает список ID чатов.
        """
        try:
            async with aiosqlite.connect(self.db_path) as db:
                query = """
                SELECT chat_id FROM chats 
                WHERE subscription_check_enabled = 1 
                AND setup_complete = 1
                """
                rows = await db.execute(query)
                results = await rows.fetchall()
                
                chat_ids = [row[0] for row in results] if results else []
                return chat_ids
        except Exception as e:
            logger.error(f"Ошибка при получении активных чатов с проверкой подписки: {e}", exc_info=True)
            return []

    async def get_active_chat_users(self, chat_id: int, days: int = 7) -> List[int]:
        """
        Получает список ID активных пользователей чата за последние N дней.
        
        Args:
            chat_id: ID чата
            days: Количество дней для определения активности
            
        Returns:
            Список ID пользователей
        """
        try:
            # Вычисляем timestamp для указанного количества дней назад
            cutoff_time = int(time.time()) - (days * 24 * 60 * 60)
            
            async with aiosqlite.connect(self.db_path) as db:
                # Запрос к таблице user_status, получаем пользователей, которые писали сообщения недавно
                query = """
                SELECT user_id FROM users_status_in_chats
                WHERE chat_id = ? AND last_update_timestamp > ?
                """
                rows = await db.execute(query, (chat_id, cutoff_time))
                results = await rows.fetchall()
                
                user_ids = [row[0] for row in results] if results else []
                
                # Если нет данных о последних сообщениях, вернем всех пользователей из чата
                if not user_ids:
                    backup_query = """
                    SELECT user_id FROM users_status_in_chats
                    WHERE chat_id = ?
                    """
                    backup_rows = await db.execute(backup_query, (chat_id,))
                    backup_results = await backup_rows.fetchall()
                    user_ids = [row[0] for row in backup_results] if backup_results else []
                
                return user_ids
        except Exception as e:
            logger.error(f"Ошибка при получении активных пользователей чата {chat_id}: {e}", exc_info=True)
            return [] 

    async def update_user_subscription_status(self, chat_id: int, user_id: int, is_subscribed: bool, timestamp: int = None) -> None:
        """Обновляет статус подписки пользователя в БД"""
        if timestamp is None:
            timestamp = int(time.time())
        
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Сначала проверяем, существует ли запись
                check_query = "SELECT 1 FROM users_status_in_chats WHERE chat_id = ? AND user_id = ?"
                cursor = await db.execute(check_query, (chat_id, user_id))
                exists = await cursor.fetchone() is not None
                
                if exists:
                    # Обновляем существующую запись
                    query = """
                    UPDATE users_status_in_chats 
                    SET is_subscribed = ?, last_update_timestamp = ?
                    WHERE chat_id = ? AND user_id = ?
                    """
                    await db.execute(query, (int(is_subscribed), timestamp, chat_id, user_id))
                else:
                    # Создаем новую запись
                    query = """
                    INSERT INTO users_status_in_chats (chat_id, user_id, is_subscribed, last_update_timestamp)
                    VALUES (?, ?, ?, ?)
                    """
                    await db.execute(query, (chat_id, user_id, int(is_subscribed), timestamp))
                
                await db.commit()
        except Exception as e:
            logger.error(f"Ошибка при обновлении статуса подписки: {e}", exc_info=True)
            
    async def update_last_subscription_check(self, chat_id: int, user_id: int, timestamp: int = None) -> None:
        """Обновляет время последней проверки подписки пользователя"""
        if timestamp is None:
            timestamp = int(time.time())
        
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Проверяем существование таблицы
                check_table = """
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='subscription_checks'
                """
                cursor = await db.execute(check_table)
                table_exists = await cursor.fetchone() is not None
                
                if not table_exists:
                    # Создаем таблицу, если она не существует
                    create_table = """
                    CREATE TABLE IF NOT EXISTS subscription_checks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        chat_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        check_timestamp INTEGER NOT NULL,
                        UNIQUE(chat_id, user_id)
                    )
                    """
                    await db.execute(create_table)
                
                # Обновляем или вставляем запись
                query = """
                INSERT INTO subscription_checks (chat_id, user_id, check_timestamp) 
                VALUES (?, ?, ?)
                ON CONFLICT(chat_id, user_id) 
                DO UPDATE SET check_timestamp = ?
                """
                await db.execute(query, (chat_id, user_id, timestamp, timestamp))
                await db.commit()
                
                logger.debug(f"Обновлено время проверки подписки для пользователя {user_id} в чате {chat_id}")
        except Exception as e:
            logger.error(f"Ошибка при обновлении времени проверки подписки: {e}", exc_info=True) 