"""
Пакет с фильтрами для бота.
"""
from .admin_filter import AdminFilter

__all__ = ['AdminFilter'] 