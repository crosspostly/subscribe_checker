from aiogram import Bot
from aiogram.enums import ChatMemberStatus
from aiogram.types import User
from html import escape

async def is_admin(bot: Bot, chat_id: int, user_id: int) -> bool:
    """Проверяет, является ли пользователь админом или создателем чата."""
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        return member.status in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
    except Exception:
        # Если не удалось получить информацию (например, бота нет в чате или пользователь вышел)
        return False

def get_user_mention_html(user: User) -> str:
    """Возвращает HTML-упоминание пользователя."""
    # user.full_name может содержать символы, которые нужно экранировать
    full_name = escape(user.full_name)
    return f"<a href='tg://user?id={user.id}'>{full_name}</a>" 